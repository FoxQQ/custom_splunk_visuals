/*
 * Visualization source
 */
define([
            'jquery',
            'underscore',
            'api/SplunkVisualizationBase',
            'api/SplunkVisualizationUtils',
            'd3'
            // Add required assets to this list
        ],
        function(
            $,
            _,
            SplunkVisualizationBase,
            vizUtils,
            d3
        ) {
  
    // Extend from SplunkVisualizationBase
    return SplunkVisualizationBase.extend({
  
        initialize: function() {
            SplunkVisualizationBase.prototype.initialize.apply(this, arguments);
            this.$el = $(this.el);

            this.$el.append('<h3>This is a custom visualization stand in.</h3>');
            this.$el.append('<p>Edit your custom visualization app to render something here.</p>');
            
            // Initialization logic goes here
        },

        // Optionally implement to format data returned from search. 
        // The returned object will be passed to updateView as 'data'
        formatData: function(data) {

            // Format data 

            return data;
        },
  
        // Implement updateView to render a visualization.
        //  'data' will be the data object returned from formatData or from the search
        //  'config' will be the configuration property object
        updateView: function(data, config) {
            
            // Draw something here
            this.$el.empty();
            console.log(data);
            let vis = d3.select(this.el).append('svg')
                .attr('width',400)
                .attr('height',200);

            vis.append('rect')
                .attr('x',0)
                .attr('y',0)
                .attr('width',100)
                .attr('height',200)
                .attr("fill",'green');
            vis.append("text").text("ie test").attr("x",100).attr("y",15);

            vis.selectAll('text').data(data.rows)
                .enter()
                .append('text')
                .text(function(d,i){return d;})
                .attr('x', 100)
                .attr("y",(d,i)=>(i+2)*15)
        },

        // Search data params
        getInitialDataParams: function() {
            return ({
                outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
                count: 10000
            });
        },

        // Override to respond to re-sizing events
        reflow: function() {
            this.invalidateUpdateView();
        }
    });
});