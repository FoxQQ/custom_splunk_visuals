# custom visuals for splunk, just install app from tar.gz file - hopefully works :D 
