/*
 * Visualization source
 */
define([
            'jquery',
            'underscore',
            'api/SplunkVisualizationBase',
            'api/SplunkVisualizationUtils',
            'd3'
            // Add required assets to this list
        ],
        function(
            $,
            _,
            SplunkVisualizationBase,
            vizUtils,
            d3
        ) {
  
    // Extend from SplunkVisualizationBase
    return SplunkVisualizationBase.extend({
  
        initialize: function() {
            SplunkVisualizationBase.prototype.initialize.apply(this, arguments);
            this.$el = $(this.el);

            this.$el.append('<h3>Orbit Chart</h3>');
            this.$el.addClass('orbit-chart');
            
            // Initialization logic goes here
        },

        // Optionally implement to format data returned from search. 
        // The returned object will be passed to updateView as 'data'
        formatData: function(data) {

            // Format data
            //console.log(data.fields);
            //console.log(data.fields[data.fields.length-1]);

            let levels = ["low","med","high"];
            let itemsPerLevel = new Array(levels.length);
            levels.forEach(function (d,i){
                itemsPerLevel[i]=getNumberofEvent(d,2);
            });
            let itemsPerLevelSet = [0 , 0, 0];
            let itemsRandomState = [Math.random()*2*Math.PI, Math.random()*2*Math.PI, Math.random()*2*Math.PI];
            data.rows.forEach(function (d,i){
               levels.forEach(function(cls){
                    if(cls==d[2]){
                        let idx = levels.indexOf(d[2]);
                        itemsPerLevelSet[idx]++;
                        d.push((itemsPerLevelSet[idx]/itemsPerLevel[idx])+itemsRandomState[idx]);
                    }
               });
            });

            function getNumberofEvent(value, column){
                let counter=0;
                data.rows.forEach(function(d){
                    if(d[column]==value){
                        counter++;
                    }
                });
                return counter;
            }
            data.fields.push({"name":"class_index"});
            let package_ = new Array(2);
            package_[0]=(data);
            package_[1]=(levels);
            return package_;
        },

        // Implement updateView to render a visualization.
        //  'data' will be the data object returned from formatData or from the search
        //  'config' will be the configuration property object
        updateView: function(package_, config) {
		    //console.log('update view variables:');
            //console.log('config',config);
		    //console.log('data',data);
		    //console.log('Fields:',data['fields'].length);
            let data = package_[0];
            let levels = package_[1];
            if(data=='undefined'){
                return;
            }
            //console.log("DATA:",data);




            let color_1 = config[this.getPropertyNamespaceInfo().propertyNamespace + 'color_1'] ||"#ffaaaa",
                color_2 = config[this.getPropertyNamespaceInfo().propertyNamespace + 'color_2'] ||"#aaffaa",
                color_3 = config[this.getPropertyNamespaceInfo().propertyNamespace + 'color_3'] ||"#ffffaa";

            let low_text = config[this.getPropertyNamespaceInfo().propertyNamespace + 'low_text'] ||"low",
                med_text = config[this.getPropertyNamespaceInfo().propertyNamespace + 'med_text'] ||"medium",
                high_text = config[this.getPropertyNamespaceInfo().propertyNamespace + 'high_text'] ||"high",
                show_orbit_labels = config[this.getPropertyNamespaceInfo().propertyNamespace + 'show_orbit_labels'] ||"yes";

            let scale_factor_1= parseFloat(config[this.getPropertyNamespaceInfo().propertyNamespace + 'scale_factor_1']) || 2.5,
                scale_factor_2= parseFloat(config[this.getPropertyNamespaceInfo().propertyNamespace + 'scale_factor_2']) || 3.3,
                scale_factor_3= parseFloat(config[this.getPropertyNamespaceInfo().propertyNamespace + 'scale_factor_3']) || 3.8;

            let margin = 10;
            let bg_color = config[this.getPropertyNamespaceInfo().propertyNamespace + 'bg_color'] ||'#444444',
                ring_color = config[this.getPropertyNamespaceInfo().propertyNamespace + 'ring_color'] ||'#999999';

            let svg_width=this.$el.width(),
                svg_height=this.$el.height();


            this.$el.empty();

            let chartid = "radar_"+generateId(10);

            let total = 0, col_sums=[];
            col_sums.length = data.fields.length;
            col_sums.fill(0);

            let svg = d3.select(this.el)
                .append('svg')
                .attr('id',chartid)
                .attr('width','100%')
                .attr('height','100%');


            let background_rect = svg.append('rect')
                .attr('x',0)
                .attr('y',0)
                .attr('width',svg_width)
                .attr('height',svg_height)
                .attr('fill',bg_color);
            let circle_basegroup = svg.append('g')
                .attr('transform','translate('+svg_width/2+','+svg_height/2+')');

            let r = svg_width>svg_height?svg_height/2:svg_width/2;
            r=r-margin;
            //let max_val =d3.max(data.rows,function(d){ return Number(d[0]) }) - d3.min(data.rows,function(d){ return Number(d[0]) });


            let quant_scale = d3.scaleBand()
                .range([0, r])
                .domain(levels)
                .paddingInner(0.75)
                .paddingOuter(0.3);


            let color_scale = function(level) {
                switch (level) {
                    case "low":
                        return color_1;
                    case "med":
                        return color_2;
                    case "high":
                        return color_3;
                    default:
                        return "#000";
                }
            };

            //console.log(data.rows);
            /*
            let outer_circle = circle_basegroup.append('circle')
                .attr('r',r)
                .attr('fill','white')
                .attr('fill-opacity',0.0)
                .attr('stroke','#444444')
                .attr('stroke-width',0.5);
            */


            circle_basegroup.append('circle')
                .attr('r',quant_scale("low"))
                .attr('fill','white')
                .attr('fill-opacity',0.0)
                .attr('stroke',ring_color)
                .attr('stroke-width',0.5)
                .attr('stroke-dasharray',2);

            circle_basegroup.append('circle')
                .attr('r',quant_scale("med"))
                .attr('fill','white')
                .attr('fill-opacity',0.0)
                .attr('stroke',ring_color)
                .attr('stroke-width',0.5)
                .attr('stroke-dasharray',2);

            circle_basegroup.append('circle')
                .attr('r',quant_scale("high"))
                .attr('fill','white')
                .attr('fill-opacity',0.0)
                .attr('stroke',ring_color)
                .attr('stroke-width',0.5).attr('stroke-dasharray',2);

            if(show_orbit_labels == "yes"){

                circle_basegroup.append('text')
                    .attr('x',quant_scale("low"))
                    .attr('y',0)
                    .attr('fill',ring_color)
                    .text(low_text);

                circle_basegroup.append('text')
                    .attr('x',quant_scale("med"))
                    .attr('y',0)
                    .attr('fill',ring_color)
                    .text(med_text);

                circle_basegroup.append('text')
                    .attr('x',quant_scale("high"))
                    .attr('y',0)
                    .attr('fill',ring_color)
                    .text(high_text);

            }

            //console.log(levels);
            //console.log(itemsPerLevel);

            let planets =svg.append('g').attr('transform','translate('+svg_width/2+','+svg_height/2+')');

            planets.selectAll('circle')
                .data(data.rows)
                .enter()
                .append('circle')
                .attr('r',function(d,i){
                    if(d[2]==levels[0]){
                        return quant_scale(d[2])/scale_factor_1;
                    }
                    else if(d[2]==levels[1]){
                        return quant_scale(d[2])/scale_factor_2;
                    }
                    else{
                        return quant_scale(d[2])/scale_factor_3;
                    }

                })
                .attr('id',function(d,i){
                    return d[1];
                })
                .attr('cx', function (d,i) {
                    return radial_x(d)
                })
                .attr('cy', function(d,i){
                    return radial_y(d);
                })
                .attr('fill-opacity',0.25)
                .attr('fill',function (d){
                    return color_scale(d[2])
                })
                .attr('stroke',function (d){
                    return color_scale(d[2])
                })
                .on('mouseover',mouseover)
                .on('mousemove',mousemove)
                .on('mouseout',mouseout);

            let planet_names =svg.append('g').attr('transform','translate('+svg_width/2+','+svg_height/2+')');
            planet_names.selectAll('text')
                .data(data.rows)
                .enter()
                .append('text')
                .attr('x',function (d,i) {
                    return radial_x(d)
                })
                .attr('y', function(d,i){
                    return radial_y(d);
                })
                .attr('text', function(d, i) {
                    return d
                });




            function radial_x(d){
                return Math.cos(Number(d[d.length-1])*2*Math.PI)*quant_scale(d[2]);
            }
            function radial_y(d){
                return Math.sin(Number(d[d.length-1])*2*Math.PI)*quant_scale(d[2]);
            }





            function setTooltipStyle(current){
                let tooltipContainer = d3.select('.tooltip-container');

                let max_width = document.getElementById(chartid).getBoundingClientRect().left + document.getElementById(chartid).getBoundingClientRect().width;
                let max_height = document.getElementById(chartid).getBoundingClientRect().top + document.getElementById(chartid).getBoundingClientRect().height;

                let x_pos=0,y_pos=0;
                if(d3.event.clientX + $('.tooltip-container')[0].clientWidth<max_width || d3.event.clientX - $('.tooltip-container')[0].clientWidth<0){
                    x_pos=d3.event.pageX;
                }
                else{
                    x_pos=d3.event.pageX - $('.tooltip-container')[0].clientWidth;
                }
                if(d3.event.clientY + $('.tooltip-container')[0].clientHeight<max_height){
                    y_pos=d3.event.pageY;
                }
                else{
                    y_pos=d3.event.pageY - $('.tooltip-container')[0].clientHeight;
                }
                tooltipContainer.style('left', (x_pos) + 'px')
                    .style('top', (y_pos) + 'px');
                d3.select(current).attr('fill-opacity',1);
            }


            function mouseover(d){
                var init = function(selection){
                    //console.log('selection:',selection);
                    selection.each(function(d){
                        //console.log(d.index);
                        let i = d.index;
                        d3.select(this)
                            .attr('class', 'tooltip-container');
                        //.style('width', 300 + 'px');
                        // Tooltip Title
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-title')
                            .text('Info');

                        // Tooltip Content
                        d3.select(this).append('p')
                                .attr('class', 'tooltip-content')
                                .html(function() {
                                    let str_ = "";
                                    for (let i=0;i<d.length;i++){
                                        str_ += data.fields[i].name +   ' : ' + d[i] + '</br>';                                       //console.log(date);

                                    }
                                    return str_;
                                });



                    });
                };

                var tooltipContainer = d3.select('body').append('div')
                    .datum(d)
                    .attr('class','tooltip-container')
                    .call(init);
                setTooltipStyle(this);


            }
            function mousemove(d){
                setTooltipStyle(this);
            }
            function mouseout(d){
                //d3.select(this).classed('arc',true).classed('highlighted',false);
                //d3.select('#tooltip').remove();
                d3.select('div.tooltip-container').remove();

                d3.select(this).attr('fill-opacity',0.25);
            }




            function generateId(size){
                let id="";
                for(let i=0;i<size;i++){
                    id+=String.fromCharCode(Math.floor(Math.random()*(58-48)+48));
                }
                return id;
            }

        },

        // Search data params
        getInitialDataParams: function() {
            return ({
                outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
                count: 10000
            });
        },

        // Override to respond to re-sizing events
        reflow: function() {
            this.invalidateUpdateView();
        }
    });
});
