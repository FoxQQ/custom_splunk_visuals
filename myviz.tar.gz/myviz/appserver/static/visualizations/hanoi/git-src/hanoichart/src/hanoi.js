
class BasicChart{
    constructor(data){
        this.data = data;
        this.margin = 30;
        this.width=window.innerWidth - this.margin*2;
        this.height=window.innerHeight - this.margin*2;
        this.svg = d3.select('#chart-container').append('svg')
            .attr('width',this.width)
            .attr('height',this.height);

        this.chartcanvas = this.svg.append('g')
            .attr('transform',`translate(${this.margin},${this.margin})`);
    }

    getCol(data, col){
        var column=[];
        for(let i=0;i<data.length;i++){
            column.push(data[i][col])
        }
        return column;
    }
}

class HanoiChart extends BasicChart{
    constructor(data){
        super(data);
        var maxVal = d3.max(this.getCol(data, 1));
        var centerline = this.width/4-this.margin/2;
        var textline = this.width*2/4+this.margin/2;

        var xScale = d3.scaleLog()
            .base(10)
            .domain([d3.min(this.getCol(data,1))/2,d3.max(this.getCol(data,1))])
            .range([0,textline]);

        var yScale = d3.scaleLinear()
            .domain([0, data.length])
            .range([0,this.height-this.margin]);


        this.g = this.chartcanvas.append('g');
        this.g.append('line')
             .attr({
               x1:centerline,
               y1:0,
               x2:centerline,
               y2:this.height,
               stroke:'black'
            });

        this.g.append('line')
            .attr('class','seperator')
            .attr({
                x1:textline,
                y1:0,
                x2:textline,
                y2:this.height,
                stroke:'black'
            });

        var barheight  =this.height/data.length-this.margin/3;
        this.g2 = this.chartcanvas.append('g');
        this.g2.selectAll('rect')
            .data(data)
            .enter()
            .append('rect')
            .attr('x',centerline)
            .attr('y', (d,i)=>yScale(i)+barheight/2)
            .attr('width',0)
            .attr('height',0)
            .on('mouseover',mouseover)
            .on('mousemove',mousemove)
            .on('mouseout',mouseout)
            .transition()
            .duration(2500)
            .attr('x',(d,i)=>centerline-xScale(d[1])/2)
            .attr('y',(d,i)=>yScale(i))
            .attr('width',(d)=>xScale(d[1]))
            .attr('height',barheight)
            .attr('class',(d,i)=>i%2==0?'bar':'bar2')
            .attr('rx','10')
            .attr('ry','10');

        function mouseover(d){

            d3.select(this).classed('highlighted',true);

            var init = function(selection){
                //console.log('selection:',selection);
                selection.each(function(d){
                    //console.log(d.index);
                    let i = d.index;
                    d3.select(this)
                        .attr('class', 'tooltip-container');
                    //.style('width', 300 + 'px');
                    // Tooltip Title
                    d3.select(this).append('p')
                        .attr('class', 'tooltip-title')
                        .text('Info');

                    // Tooltip Content
                    d3.select(this).append('p')
                        .attr('class', 'tooltip-content')
                        .html(data.fields[0].name + ' : ' + data.rows[i][0] + '</br>'
                            + data.fields[1].name + ' : ' + data.rows[i][1] + '</br>'
                            + 'Percentage' + ' : ' + (parseFloat(data.rows[i][1])*100/sum_).toFixed(2)+'%');

                });
            };

            var tooltipContainer = d3.select('body').append('div')
                .datum(d)
                .attr('class','tooltip-container')
                .call(init);

            tooltipContainer.style('left', (d3.event.pageX ) + 'px')
                .style('top', (d3.event.pageY ) + 'px');


        }
        function mousemove(d){

            d3.select('div.tooltip-container').style('left', (d3.event.pageX ) + 'px')
                .style('top', (d3.event.pageY ) + 'px');


            //console.log(d3.mouse(this));
        }
        function mouseout(d){
            d3.select(this).classed('highlighted',false);
            d3.select('div.tooltip-container').remove();
        }


        this.g3 = this.chartcanvas.append('g').selectAll('text')
            .data(data)
            .enter().append('text')
            .attr('x',textline)
            .attr('y',(d,i)=>yScale(i)+barheight/2)
            .attr('class','letter')
            .attr('data-letter',(d)=>d[0])
            .text((d)=>d[0]);


    }
}

var dataarray = [
    ['All Mail',50],
    ['Total filtered',10000],
    ['L1',1000],
    ['L2',850],
    ['L3',50650],
];
console.log(dataarray);

var container = new HanoiChart(dataarray);
console.log('works');
