/*
 * Visualization source
 */
define([
            'jquery',
            'underscore',
            'api/SplunkVisualizationBase',
            'api/SplunkVisualizationUtils',
            'd3'
            // Add required assets to this list
        ],
        function(
            $,
            _,
            SplunkVisualizationBase,
            vizUtils,
            d3
        ) {
  
    // Extend from SplunkVisualizationBase
    return SplunkVisualizationBase.extend({
  
        initialize: function() {
            SplunkVisualizationBase.prototype.initialize.apply(this, arguments);
            this.$el = $(this.el);

            //this.$el.append('<h3>Chart Header</h3>');
            this.$el.addClass('hanoi-chart');

            // Initialization logic goes here
        },

        // Optionally implement to format data returned from search. 
        // The returned object will be passed to updateView as 'data'
        formatData: function(data) {

            return data
        },
  
        // Implement updateView to render a visualization.
        //  'data' will be the data object returned from formatData or from the search
        //  'config' will be the configuration property object
        updateView: function(data, config) {

		    this.$el.empty();
            var svg_width=this.$el.width(),
                svg_height=this.$el.height();
            //console.log('width',svg_width,'height',svg_height);
            var d_length = data.rows.length,
                margin=20;

            var maxVal = -Number.MAX_VALUE,
                minVal = Number.MAX_VALUE;
            for(let i=0;i<d_length;i++){
                let val = parseFloat(data.rows[i][1]);
                maxVal = Max(maxVal, val);
                minVal = Min(minVal, val);
            }

            let aspectratio=parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'aspectratio']) ||6;
            let logbase=2;
            let duration=parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'duration']) ||2000;
            let transitionflag=config[this.getPropertyNamespaceInfo().propertyNamespace + 'transitionflag'] ||"no";
            let coloroption=config[this.getPropertyNamespaceInfo().propertyNamespace + 'coloroption'] ||"dark";

            let color_start=config[this.getPropertyNamespaceInfo().propertyNamespace + 'colorstart'] || '#000000',
                color_end=config[this.getPropertyNamespaceInfo().propertyNamespace + 'colorend'] || '#ffffff';

            var centerline = svg_width/aspectratio-margin/2;
            var textline = svg_width*2/aspectratio+margin/2;
            var xScale = d3.scaleLog()
                .base(logbase)
                .domain([minVal/2,maxVal])
                .range([margin,textline-margin*2]);

            var yScale = d3.scaleLinear()
                .domain([0, d_length])
                .range([margin,svg_height-margin]);
            let color;
            switch(coloroption) {
                case 'css':
                    color=d3.scaleLinear().range(['#000000']);
                    break;
                case 'custom':
                    color=d3.scaleLinear()
                        .interpolate(d3.interpolateRgb)
                        .domain([0,d_length])
                        .range([color_start,color_end]);
                    break;
                default:
                    color= d3.scaleOrdinal().range(d3.schemeDark2);
            }
            var chart = d3.select(this.el)
                .append('svg')
                .attr('id','chart')
                .attr('width',svg_width)
                .attr('height',svg_height);

            let g1 = chart.append('g');
            g1.append('line')
                .attr('class','centerline')
                .attr('x1',centerline)
                .attr('y1',0)
                .attr('x2',centerline)
                .attr('y2',svg_height);

            g1.append('line')
                .attr('class','textline')
                .attr('x1',textline)
                .attr('y1',0)
                .attr('x2',textline)
                .attr('y2',svg_height);


            var barheight  =svg_height/d_length-margin/3;
            let g2 = chart.append('g')
                .attr('id','bar-group');

            if(transitionflag=='yes'){
                g2.selectAll('rect')
                    .data(data.rows)
                    .enter()
                    .append('rect')
                    .attr('x',centerline)
                    .attr('y', (d,i)=>yScale(i)+barheight/2)
                    .attr('width',0)
                    .attr('height',0)
                    .on('mouseover',mouseover)
                    .on('mousemove',mousemove)
                    .on('mouseout',mouseout)
                    .transition()
                    .duration(duration)
                    .attr('x',(d,i)=>{
                        return centerline-(xScale(d[1])/2);
                    })
                    .attr('y',(d,i)=>yScale(i))
                    .attr('width',(d)=>xScale(d[1]))
                    .attr('height',barheight-10)
                    .attr('class','rect')
                    .attr('fill',(d,i)=>color(i))
                    .attr('rx','10')
                    .attr('ry','10');

            }else{
                g2.selectAll('rect')
                    .data(data.rows)
                    .enter()
                    .append('rect')
                    .on('mouseover',mouseover)
                    .on('mousemove',mousemove)
                    .on('mouseout',mouseout)
                    .attr('x',(d,i)=>{
                        return centerline-(xScale(d[1])/2);
                    })
                    .attr('y',(d,i)=>yScale(i))
                    .attr('width',(d)=>xScale(d[1]))
                    .attr('height',barheight-10)
                    .attr('class','rect')
                    .attr('fill',(d,i)=>color(i))
                    .attr('rx','10')
                    .attr('ry','10');
            }


            let g3 = chart.append('g').selectAll('text')
                .data(data.rows)
                .enter().append('text')
                .attr('x',textline)
                .attr('y',(d,i)=>yScale(i)+barheight/2)
                .attr('class','letter')
                .attr('data-letter',(d)=>d[0])
                .text((d)=>d[0]);

            function mouseover(d, i){

                d3.select(this).classed('highlighted',true);

                var init = function(selection){
                    selection.each(function(d){


                        d3.select(this)
                            .attr('class', 'tooltip-container');
                        //.style('width', 300 + 'px');
                        // Tooltip Title
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-title')
                            .text('Info');

                        // Tooltip Content
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-content')
                            .html(data.fields[0].name + ' : ' + data.rows[i][0] + '</br>'
                                + data.fields[1].name + ' : ' + data.rows[i][1] + '</br>');

                    });
                };

                var tooltipContainer = d3.select('body').append('div')
                    .datum(d)
                    .attr('class','tooltip-container')
                    .call(init);

                tooltipContainer.style('left', (d3.event.pageX ) + 'px')
                    .style('top', (d3.event.pageY ) + 'px');


            }
            function mousemove(d){

                d3.select('div.tooltip-container').style('left', (d3.event.pageX ) + 'px')
                    .style('top', (d3.event.pageY ) + 'px');


                //console.log(d3.mouse(this));
            }
            function mouseout(d){
                d3.select(this).classed('highlighted',false);
                d3.select('div.tooltip-container').remove();
            }

            function Max(x ,y){
                return x>y?x:y;
            }
            function Min(x ,y){
                return x<y?x:y;
            }

        },

        // Search data params
        getInitialDataParams: function() {
            return ({
                outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
                count: 10000
            });
        },

        // Override to respond to re-sizing events
        reflow: function() {
            this.invalidateUpdateView();
        }
    });
});
