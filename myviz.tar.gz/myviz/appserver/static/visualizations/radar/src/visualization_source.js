/*
 * Visualization source
 */
define([
            'jquery',
            'underscore',
            'api/SplunkVisualizationBase',
            'api/SplunkVisualizationUtils',
            'd3'
            // Add required assets to this list
        ],
        function(
            $,
            _,
            SplunkVisualizationBase,
            vizUtils,
            d3
        ) {
  
    // Extend from SplunkVisualizationBase
    return SplunkVisualizationBase.extend({
  
        initialize: function() {
            SplunkVisualizationBase.prototype.initialize.apply(this, arguments);
            this.$el = $(this.el);

            this.$el.append('<h3>Radar Chart</h3>');
            this.$el.addClass('radar-chart');
            
            // Initialization logic goes here
        },

        // Optionally implement to format data returned from search. 
        // The returned object will be passed to updateView as 'data'
        formatData: function(data) {

            // Format data 
                //console.log('data in format data:');

            let naming_col=1;

            let fields=[],rows=[], labels=[];


            if(naming_col){

                data.fields.forEach(function(d,i){
                    if(i===0){
                        return;
                    }
                    fields.push(d);
                });

                data.rows.forEach(function(d,i){
                    let row=[];
                    d.forEach(function(d,i){
                        if(i===0){
                            labels.push(d);
                        }
                        else{
                            row.push(d);
                        }
                    });
                    rows.push(row);
                });
            }

            data.rows = rows;
            data.fields = fields;
            data.labels = labels;
            return data;
        },
  
        // Implement updateView to render a visualization.
        //  'data' will be the data object returned from formatData or from the search
        //  'config' will be the configuration property object
        updateView: function(data, config) {
		    //console.log('update view variables:');
            //console.log('config',config);
		    //console.log('data',data);
		    //console.log('Fields:',data['fields'].length);
            if(data=='undefined'){
                return;
            }

            let svg_width=this.$el.width(),
                svg_height=this.$el.height();


            this.$el.empty();

            let chartid = "radar_"+generateId(10);

            let circle_radius = parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'circle_radius']) || 5,
                circle_opacity = parseFloat(config[this.getPropertyNamespaceInfo().propertyNamespace + 'circle_opacity']) || 1.0,
                area_opacity = parseFloat(config[this.getPropertyNamespaceInfo().propertyNamespace + 'area_opacity'] ),
                radar_flag = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'radar_flag']) || 'yes',
                axis_shared = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'axis_shared']) || 'yes',
                axis_names = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'axis_names']),
                axis_logtype = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'axis_logtype']) || 'linear',
                pow_exponent = parseFloat(config[this.getPropertyNamespaceInfo().propertyNamespace + 'pow_exponent']) || 2,
                label_percentage = config[this.getPropertyNamespaceInfo().propertyNamespace + 'label_percentage'] || "yes",
                radar_padding = parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'radar_padding']) || 20;


            let total = 0, col_sums=[];
            col_sums.length = data.fields.length;
            col_sums.fill(0);
            if(label_percentage=="yes"){
                data.rows.forEach(function(row, i){
                    let col_sum =0;
                    row.forEach(function(d, i){
                        col_sums[i]+=Number(d);
                        total+=Number(d);
                    });
                });
            }


            if(typeof axis_names!='undefined'){
                axis_names = axis_names.replace(/\s/g, '');
                if(axis_names!=""){
                    axis_names= axis_names.split(',');
                }
            }
            //console.log(typeof axis_names);
            let logtype_idx=[];
            if(typeof axis_names=='object'){
                axis_names.forEach(function(d){
                        //console.log(d);
                });

            }

            let svg = d3.select(this.el)
                .append('svg')
                .attr('id',chartid)
                .attr('width','100%')
                .attr('height','100%');

            let radar_skeleton = svg.append('g')
                .attr('transform','translate('+svg_width/2+','+svg_height/2+')');

            let n_axes = data['fields'].length;


            let color = d3.scaleOrdinal().range(d3.schemeDark2);

            let axes_length = svg_height<svg_width?svg_height/2-radar_padding:svg_width/2-radar_padding,
                spacer_axis_name=10;


            let radial_scale = d3.scaleLinear()
                .domain([0, n_axes])
                .range([0, 2 * Math.PI]);
            if(radar_flag==='yes'){

                radar_skeleton.append('circle')
                    .attr('cx', 0)
                    .attr('cy', 0)
                    .attr('r', axes_length)
                    .attr('opacity', 0.1)
                    .attr('fill', '#aaa')
                    .attr('stroke', '#000')
                    .attr('stroke-width', '1px');

                radar_skeleton.append('circle')
                    .attr('cx', 0)
                    .attr('cy', 0)
                    .attr('r', axes_length/2)
                    .attr('opacity', 0.1)
                    .attr('fill', '#aaa')
                    .attr('stroke', '#000')
                    .attr('stroke-width', '1px');

            }
            radar_skeleton.selectAll('line')
                .data(data.fields)
                .enter()
                .append('line')
                .attr('x1',0)
                .attr('y1',0)
                .attr('x2',function (d,i){
                    return Math.cos(radial_scale(i)-Math.PI/2)*axes_length;
                })
                .attr('y2',function(d,i){
                    return Math.sin(radial_scale(i)-Math.PI/2)*axes_length;
                })
                .attr('stroke','black');
            let axes_names = radar_skeleton.selectAll('text')
                .data(data.fields)
                .enter()
                .append('text')
                .text(function (d, i){
                    return d.name + (label_percentage=="yes"?' '+ Math.round(col_sums[i]/total*100).toFixed(1) + '%':"") ;
                })
                .attr('x',function (d,i){
                    return Math.cos(radial_scale(i)-Math.PI/2)*axes_length+spacer_axis_name;
                })
                .attr('y',function(d,i){
                    return Math.sin(radial_scale(i)-Math.PI/2)*axes_length+spacer_axis_name;
                })
                .attr('style','visibility:visible;');


            axes_names._groups[0].forEach(function (d,i){
                let x = d.getAttribute('x'),
                    y=d.getAttribute('y'),
                    bbox = d.getBBox();

                if(x<0){
                    d.setAttribute('x',x-bbox.width-2*spacer_axis_name);
                }
                if(y<0){
                    d.setAttribute('y',y-bbox.height);
                }
            });
            let scales = [];
            if(axis_shared == 'no') {

                for (let i = 0; i < n_axes; i++) {
                    let col_max = get_column_max(i);


                    //ADD SCALE TYPE OPTION HERE!!!

                    let scale;
                    if(axis_logtype=='linear'){
                        scale = d3.scaleLinear()
                            .domain([0, col_max])
                            .range([0, axes_length]);
                    }
                    else if(axis_logtype=='log') {
                        scale = d3.scaleLog()
                            .domain([1, col_max])
                            .range([0, axes_length]);
                    }
                    else if(axis_logtype=='pow'){
                        scale = d3.scalePow()
                            .exponent(pow_exponent)
                            .domain([0, col_max])
                            .range([0, axes_length]);
                    }
                    else if(axis_logtype=='sqrt'){
                        scale = d3.scaleSqrt()
                            .domain([0, col_max])
                            .range([0, axes_length]);
                    }
                    scales.push(scale);
                }
            } else {
                for(let i=0; i<n_axes; i++){
                    let max_value = 0;
                    data.rows.forEach(function (row){
                        row.forEach(function (date){
                            if(Number(date)>max_value){
                                max_value=Number(date);
                            }
                        });
                    });


                    let scale;
                    if(axis_logtype=='linear'){
                        scale = d3.scaleLinear()
                            .domain([0, max_value])
                            .range([0, axes_length]);
                    }
                    else if(axis_logtype=='log') {
                        scale = d3.scaleLog()
                            .domain([1, max_value])
                            .range([0, axes_length]);
                    }
                    else if(axis_logtype=='pow'){
                        scale = d3.scalePow()
                            .domain([0, max_value])
                            .range([0, axes_length]);
                    }
                    else if(axis_logtype=='sqrt'){
                        scale = d3.scaleSqrt()
                            .domain([0, max_value])
                            .range([0, axes_length]);
                    }
                    scales.push(scale);
                }
            }
            let radar_data = svg.append('g')
                .attr('transform','translate('+svg_width/2+','+svg_height/2+')');

            radar_data.selectAll('path')
                .data(data.rows)
                .enter()
                .append('path')
                .attr('d',function(d,i){
                    return build_d(d, scales);
                })
                .attr('fill',function (d,i){ return color(i);})
                .attr('class',function(d,i){return 'radar-area-'+data.labels[i];})
                .attr('fill-opacity',area_opacity)
                .attr('stroke',function(d,i){return color(i);});

            for (let ax=0;ax<n_axes;ax++){
                let ax_array = [];
                for (let i=0;i<data.rows.length;i++){
                    ax_array.push(Number(data.rows[i][ax]));
                }

                let grp = svg.append('g').attr('transform','translate('+svg_width/2+','+svg_height/2+')').attr('id',chartid+'_ax_'+ax);

                grp.selectAll('circle')
                    .data(ax_array)
                    .enter()
                    .append('circle')
                    .attr('cx',function(d){
                        if(axis_logtype=='log' && Number(d)==0){
                            return 0;
                        }
                        else {
                            return Number(radial_x(ax) * scales[ax](Number(d)));

                        }

                    })
                    .attr('cy',function(d){
                        if(axis_logtype=='log' && Number(d)==0){
                            return 0;
                        }else {
                            return Number(radial_y(ax) * scales[ax](Number(d)));
                        }

                    })
                    .attr('r',circle_radius)
                    .attr('fill', function(d,i){
                        return color(i);
                    })
                    .attr('opacity', circle_opacity)
                    .attr('class', function(d,i){return 'radar-circle-'+data.labels[i];})
                    .on('mouseover',mouseover_circle)
                    .on('mouseout',mouseout_circle);
            }



            function mouseover_circle(d,i){
                let offset = 10;
                let tooltip = svg.append('g').attr('transform','translate('+(svg_width/2+offset)+','+(svg_height/2+offset)+')').attr('class','tooltip-circle');

                let tooltip_text = tooltip.append('text')
                    .text(function(){
                        return data.labels[i]+':'+d;
                    });

                let bbox = tooltip.selectAll('text').node().getBBox();
                tooltip.selectAll('text').remove();

                tooltip.append('rect')
                    .attr('x', Number(this.getAttribute('cx')))
                    .attr('y', Number(this.getAttribute('cy')) - circle_radius -  Number(bbox['height']))
                    .attr('width', Number(bbox['width']))
                    .attr('height', Number(bbox['height'])+5)
                    .classed('radar-tooltip-background',true)
                    .attr('fill','#000');

                tooltip.append('text')
                    .text(function(){
                        return data.labels[i]+':'+d;
                    })
                    .attr('fill','#fff')
                    .classed('radar-tooltip-text',true)
                    .attr('x',Number(this.getAttribute('cx')))
                    .attr('y', Number(this.getAttribute('cy')) - circle_radius);

                /*

                 */
            }

            function mouseout_circle() {
                d3.selectAll('.tooltip-circle').remove();
            }


            function build_d(data, scales){
                let d_str = '';
                for (let i=0;i<data.length;i++){
                    d_str += i==0?'M':'L';
                    d_str +=get_coordinate(data[i], i, scales);

                }
                d_str += "L"+get_coordinate(data[0], 0, scales);
                return d_str;
            }

            function get_coordinate(date, i, scales){
                    let rad_x = radial_x(i),
                        rad_y = radial_y(i),
                        ax_pos;
                    if(axis_logtype=='log' && Number(date)==0){
                        ax_pos=0;
                    }else{
                        ax_pos = scales[i](Number(date));
                    }
                    let coord = parseFloat(rad_x * ax_pos).toFixed(4) + ',' + parseFloat(rad_y * ax_pos).toFixed(4);
                    return coord;
            }

            function radial_x(i){
                return Math.cos(radial_scale(i)-Math.PI/2);
            }
            function radial_y(i){
                return Math.sin(radial_scale(i)-Math.PI/2);
            }


            function generateId(size){
                let id="";
                for(let i=0;i<size;i++){
                    id+=String.fromCharCode(Math.floor(Math.random()*(58-48)+48));
                }
                return id;
            }

            function get_column_max(col){
                let max = 0;
                for(let j=0; j<data.rows.length;j++){
                    let val = Number(data.rows[j][col]);
                    if(val>max){
                        max=val;
                    }
                }
                return max;
            }
        },

        // Search data params
        getInitialDataParams: function() {
            return ({
                outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
                count: 10000
            });
        },

        // Override to respond to re-sizing events
        reflow: function() {
            this.invalidateUpdateView();
        }
    });
});

/*
TODO:



    radar circles
    legend area colors

    input menu:
     color
     scale type for each axis



     check logging verosity
 */
