/*
 * Visualization source
 */
define([
            'jquery',
            'underscore',
            'api/SplunkVisualizationBase',
            'api/SplunkVisualizationUtils',
            'd3'
            // Add required assets to this list
        ],
        function(
            $,
            _,
            SplunkVisualizationBase,
            vizUtils,
            d3
        ) {
  
    // Extend from SplunkVisualizationBase
    return SplunkVisualizationBase.extend({
  
        initialize: function() {
            SplunkVisualizationBase.prototype.initialize.apply(this, arguments);
            this.$el = $(this.el);

            this.$el.append('<h3>Radar Chart</h3>');
            this.$el.addClass('radar-chart');
            
            // Initialization logic goes here
        },

        // Optionally implement to format data returned from search. 
        // The returned object will be passed to updateView as 'data'
        formatData: function(data) {

            // Format data 
                //console.log('data in format data:');
            console.log(data);

            return data;
        },
  
        // Implement updateView to render a visualization.
        //  'data' will be the data object returned from formatData or from the search
        //  'config' will be the configuration property object
        updateView: function(data, config) {
		    //console.log('update view variables:');
            //console.log('config',config);
		    //console.log('data',data);
		    //console.log('Fields:',data['fields'].length);
            if(data=='undefined'){
                return;
            }

            let svg_width=this.$el.width(),
                svg_height=this.$el.height();

            this.$el.empty();

            let chartid = "radar_"+generateId(10);
            let svg = d3.select(this.el)
                .append('svg')
                .attr('id',chartid)
                .attr('width','100%')
                .attr('height','100%');

            let radar_skeleton = svg.append('g')
                .attr('transform','translate('+svg_width/2+','+svg_height/2+')');

            let n_axes = data['fields'].length;
            let axes_length = svg_height<svg_width?svg_height/3:svg_width/3;


            let radial_scale = d3.scaleLinear()
                .domain([0, n_axes])
                .range([0, 2 * Math.PI]);

            radar_skeleton.selectAll('line')
                .data(data.fields)
                .enter()
                .append('line')
                .attr('x1',0)
                .attr('y1',0)
                .attr('x2',function (d,i){
                    return Math.cos(radial_scale(i)-Math.PI/2)*axes_length;
                })
                .attr('y2',function(d,i){
                    return Math.sin(radial_scale(i)-Math.PI/2)*axes_length;
                })
                .attr('stroke','black');
            radar_skeleton.selectAll('text')
                .data(data.fields)
                .enter()
                .append('text')
                .text(function (d){
                    return d.name;
                })
                .attr('x',function (d,i){
                    return Math.cos(radial_scale(i)-Math.PI/2)*axes_length+10;
                })
                .attr('y',function(d,i){
                    return Math.sin(radial_scale(i)-Math.PI/2)*axes_length+10;
                });

            let scales = [];
            for (let i=0;i<n_axes;i++){
                //console.log(data.columns[i]);
                let col_max = get_column_max(i);
                //console.log('min',i, d3.min(data.columns[i].map(function(d){return Number(d);})), d3.max(data.columns[i].map(function(d){return Number(d);})));
                let scale = d3.scaleLinear()
                    .domain([0, col_max])
                    .range([0, axes_length]);
                scales.push(scale);
            }
            let radar_data = svg.append('g')
                .attr('transform','translate('+svg_width/2+','+svg_height/2+')');

            let color = d3.scaleOrdinal().range(d3.schemeDark2);
            radar_data.selectAll('path')
                .data(data.rows)
                .enter()
                .append('path')
                .attr('d',function(d,i){
                    return build_d(d);
                })
                .attr('fill',function (d,i){ return color(i);})
                .attr('opacity',0.3);

            for (let ax=0;ax<n_axes;ax++){
                let ax_array = [];
                for (let i=0;i<data.rows.length;i++){
                    ax_array.push(Number(data.rows[i][ax]));
                }
                console.log(ax_array);
                let grp = svg.append('g').attr('transform','translate('+svg_width/2+','+svg_height/2+')').attr('id',chartid+'_ax_'+ax);

                grp.selectAll('circle')
                    .data(ax_array)
                    .enter()
                    .append('circle')
                    .attr('cx',function(d){

                        return Number(radial_x(ax) * scales[ax](Number(d)));
                    })
                    .attr('cy',function(d){
                        return Number(radial_y(ax) * scales[ax](Number(d)));
                    })
                    .attr('r',5)
                    .attr('fill', function(d,i){
                        return color(i);
                    });

            }

/*
            for (let i=0;i<data.rows.length;i++){
                console.log('circles for row',i,'with data', data.rows[i]);
                radar_data.selectAll('circle').data(data.rows[i])
                    .enter()
                    .append('circle')
                    .attr('x',function(d,i){
                        console.log(d, i);
                        return radial_x(i) + scales[i](Number(d));
                    })
                    .attr('y',function(d, i){
                        return radial_y(i) + scales[i](Number(d));
                    })
                    .attr('r',5);

            }*/
            function testover(d,i){
                console.log(d, i);
            }


            function build_d(data){
                let d_str = '';
                for (let i=0;i<data.length;i++){
                    d_str += i==0?'M':'L';
                    d_str +=get_coordinate(data[i], i);

                }
                return d_str;
            }

            function get_coordinate(date, i){
                    let rad_x = radial_x(i),
                        rad_y = radial_y(i),
                        ax_pos = scales[i](Number(date));

                    let coord = rad_x * ax_pos + ',' + rad_y * ax_pos;
                    return coord;
            }

            function radial_x(i){
                return Math.cos(radial_scale(i)-Math.PI/2);
            }
            function radial_y(i){
                return Math.sin(radial_scale(i)-Math.PI/2);
            }

            function mouseover(d){

                var active_arc = d3.arc()
                    .innerRadius(r)
                    .outerRadius(r+10)
                    .startAngle(d.startAngle)
                    .endAngle(d.endAngle);

                d3.select(this).classed('highlighted',true).classed('arc',false);

                chart.append('path')
                    .attr('d',active_arc)
                    .attr('class','active_arc_'+data.rows[d.index][0])
                    .attr('fill',color(d.index))
                    .attr('fill-opacity', 0.5)
                    .attr('id','active_arc');

                var init = function(selection){
                    //console.log('selection:',selection);
                    selection.each(function(d){
                        //console.log(d.index);
                        let i = d.index;
                        d3.select(this)
                            .attr('class', 'tooltip-container');
                            //.style('width', 300 + 'px');
                        // Tooltip Title
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-title')
                            .text('Info');

                        // Tooltip Content
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-content')
                            .html(data.fields[0].name + ' : ' + data.rows[i][0] + '</br>'
                                + data.fields[1].name + ' : ' + data.rows[i][1] + '</br>'
                                + 'Percentage' + ' : ' + (parseFloat(data.rows[i][1])*100/sum_).toFixed(2)+'%');

                    });
                };

                var tooltipContainer = d3.select('body').append('div')
                    .datum(d)
                    .attr('class','tooltip-container')
                    .call(init);

                setTooltipStyle();

            }
            function mousemove(){
                setTooltipStyle();
            }
            function mouseout(d){
                d3.select(this).classed('arc',true).classed('highlighted',false);
                //d3.select('#tooltip').remove();
                d3.select('#active_arc').remove();
                d3.select('div.tooltip-container').remove();
            }

            function generateId(size){
                let id="";
                for(let i=0;i<size;i++){
                    id+=String.fromCharCode(Math.floor(Math.random()*(58-48)+48));
                }
                return id;
            }

            function get_column_max(col){
                let max = 0;
                for(let j=0; j<data.rows.length;j++){
                    let val = Number(data.rows[j][col]);
                    if(val>max){
                        max=val;
                    }
                }
                return max;
            }
        },

        // Search data params
        getInitialDataParams: function() {
            return ({
                outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
                count: 10000
            });
        },

        // Override to respond to re-sizing events
        reflow: function() {
            this.invalidateUpdateView();
        }
    });
});
