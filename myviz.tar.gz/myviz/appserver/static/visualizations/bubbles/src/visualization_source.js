/*
 * Visualization source
 */
define([
            'jquery',
            'underscore',
            'api/SplunkVisualizationBase',
            'api/SplunkVisualizationUtils',
            'd3'
            // Add required assets to this list
        ],
        function(
            $,
            _,
            SplunkVisualizationBase,
            vizUtils,
            d3
        ) {
  
    // Extend from SplunkVisualizationBase
    return SplunkVisualizationBase.extend({
  
        initialize: function() {
            SplunkVisualizationBase.prototype.initialize.apply(this, arguments);
            this.$el = $(this.el);

            this.$el.append('<h3>The input data seems not to be in the correct format. You need 2 columns: 1. naming, 2. values; The last entry is used to generate the trend arrow and value.</h3>');
            this.$el.addClass('my-pie-chart');
            
            // Initialization logic goes here
        },

        // Optionally implement to format data returned from search. 
        // The returned object will be passed to updateView as 'data'
        formatData: function(data) {

            // Format data 
                //console.log('data in format data:');
            /*
            data=data.rows;
                let vals=[],logs=[];
                for(let row in data){
                    //console.log(data[row]);
                    logs.push(data[row][0]);
                    vals.push(data[row][1]);
                }
                logs.pop();
                vals.pop();

                //console.log(data);
            return vals;
            */
            return data
        },
  
        // Implement updateView to render a visualization.
        //  'data' will be the data object returned from formatData or from the search
        //  'config' will be the configuration property object
        updateView: function(data, config) {
		    //console.log('update view variables:');
            //console.log('config',config);
		    //console.log('data',data);

            let svg_width=this.$el.width(),svg_height=this.$el.height();

		    this.$el.empty();
            ///reading options from the webform


            let interpolator_type =  config[this.getPropertyNamespaceInfo().propertyNamespace + 'interpolator_type'] || "Rainbow",
                support_lines_flag = config[this.getPropertyNamespaceInfo().propertyNamespace + 'support_lines_flag'] || "yes",
                support_lines_color = config[this.getPropertyNamespaceInfo().propertyNamespace + 'support_lines_color'] || "#cccccc",
                support_lines_dashed = config[this.getPropertyNamespaceInfo().propertyNamespace + 'support_lines_dashed'] || "yes",
                support_lines_width = parseFloat(config[this.getPropertyNamespaceInfo().propertyNamespace + 'support_lines_width']) || 0.5,
                r_max=parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'r_max']) || 50,
                r_min=parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'r_min']) || 10,
                box_edges=parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'box_edges']) || 10,
                box_bg=(config[this.getPropertyNamespaceInfo().propertyNamespace + 'box_bg']) || "#ffffff",
                box_stroke_color=(config[this.getPropertyNamespaceInfo().propertyNamespace + 'box_stroke_color']) || "#cccccc",
                box_stroke_width=parseFloat(config[this.getPropertyNamespaceInfo().propertyNamespace + 'box_stroke_width']) || 1,
                box_spacing=parseFloat(config[this.getPropertyNamespaceInfo().propertyNamespace + 'box_spacing']) || 0,
                headertext=(config[this.getPropertyNamespaceInfo().propertyNamespace + 'headertext']) || "None",
                headertext_color=(config[this.getPropertyNamespaceInfo().propertyNamespace + 'headertext_color']) || "#000000",
                headertext_size=parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'headertext_size']) || 18,
                headerbox_color=(config[this.getPropertyNamespaceInfo().propertyNamespace + 'headerbox_color']) || "#ffffff",
                sumlink = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'sumlink']) || "#";

            switch(interpolator_type){
                case "Virdis":
                    interpolator_type=d3.interpolateViridis;
                    break;
                case "Plasma":
                    interpolator_type=d3.interpolatePlasma;
                    break;
                case "Inferno":
                    interpolator_type=d3.interpolateInferno;
                    break;
                case "Magma":
                    interpolator_type=d3.interpolateMagma;
                    break;
                case "Warm":
                    interpolator_type=d3.interpolateWarm;
                    break;
                case "Cool":
                    interpolator_type=d3.interpolateCool;
                    break;
                default:
                    interpolator_type=d3.interpolateRainbow;
                    break;
            }
            let header_height = box_stroke_width + headertext_size+10;


            //transform splunk dateformat to d3 readable date format
            data.rows.forEach((d)=>{
                d[0]=new Date(d[0]);
            });
            //get all values for y axis
            let y_domain =data.rows.map(function(d) {
                return d[1];
            });
            let r_domain = data.rows.map((d)=>parseInt(d[2]));

            let svg = d3.select(this.el)
                .append('svg')
                .attr('id','chart')
                .attr('width','100%')
                .attr('height','100%');

            let boxgroup = svg.append('g').attr('class','boxgroup');
            boxgroup.append('rect')
                .classed("header-box",true)
                .attr("x",box_stroke_width + box_spacing)
                .attr("y",box_stroke_width)
                .attr("rx",box_edges+"px")
                .attr("ry", box_edges+"px")
                .attr("width", svg_width-box_stroke_width-box_spacing*2)
                .attr("height", header_height*2)
                .attr("fill",headerbox_color)
                .attr("stroke",box_stroke_color)
                .attr("stroke-width",box_stroke_width+"px");
            boxgroup.append('rect')
                .classed('rect-background',true)
                .attr("x",box_stroke_width + box_spacing)
                .attr("y",box_stroke_width*2 + header_height)
                .attr("width",svg_width-box_stroke_width-box_spacing*2)
                .attr("height",svg_height-box_stroke_width - header_height)
                .attr("rx",box_edges+"px")
                .attr("ry",box_edges+"px")
                .attr("fill",box_bg)
                .attr("stroke",box_stroke_color)
                .attr("stroke-width",box_stroke_width+"px");


            /////////HEADER Text////////////////////////////////////////////////////////////////////////
            let textgroup = boxgroup.append('g');
            let textlink = textgroup.append('a');

            textlink.append('text')
                .text(headertext)
                .style('font-wheight','bold')
                .style('font-size',headertext_size+'px');

            let widthSumtext = textgroup.node().getBBox().width,
                heightSumtext = textgroup.node().getBBox().height;

            textgroup.remove();
            textgroup = boxgroup.append('g')
                .attr('id','header-text').attr("transform",`translate(${svg_width/2-widthSumtext/2},${header_height + box_stroke_width - heightSumtext/4})`);
            textlink = textgroup.append('a')
                .attr('class','single-drilldown')
                .attr('href',sumlink);


            textlink.append('text')
                .classed("header-text",true)
                .text(headertext)
                .style('font-wheight','bold')
                .style('fill',headertext_color)
                .style('font-size', headertext_size+'px');


            //////////////////////////BUBLES CHART ////////////////////////////////////////


            let y_scale = d3.scaleBand()
                .domain(y_domain)
                .range([0,svg_height]);

            let y_axis = d3.axisLeft()
                .scale(y_scale);

            let y_axis_group = svg.append('g')
                .classed("y-axis",true)
                .call(y_axis);

            let y_axis_width = y_axis_group.node().getBBox().width;
            y_axis_group.remove();


            let margins = {
                left:y_axis_width+20+box_spacing,
                right:20+r_max*1.5+box_spacing,
                top:20 + header_height + box_stroke_width,
                bottom:5
            };

            let chart_width = svg_width - margins.left - margins.right,
                chart_height = svg_height - margins.top - margins.bottom - header_height;



            let x_scale = d3.scaleTime()
                .range([0,chart_width - r_max * 1.5])
                .domain(d3.extent(data.rows, (d)=>{
                    return d[0];
                }));

            y_scale = d3.scaleBand()
                .domain(y_domain)
                .range([0,chart_height]);
            let y_bandwidth = y_scale.bandwidth();

            let color = d3.scaleSequential()
                .interpolator(interpolator_type)
                .domain([d3.min(r_domain), d3.max(r_domain)]);

            let radius_scale = d3.scaleLinear()
                .domain([d3.min(r_domain),d3.max(r_domain)])
                .range([r_min,r_max]);


            let chart = svg.append('g')
                .classed("chart-group",true)
                .attr("transform",`translate(${margins.left},${margins.top })`);

            let x_axis = d3.axisBottom()
                .scale(x_scale);

            y_axis = d3.axisLeft(y_scale);


            if(support_lines_flag=="yes"){
                y_domain.forEach((d)=>{
                    chart.append('line')
                        .attr("x1", 0)
                        .attr("y1", y_scale(d)+y_bandwidth/2)
                        .attr("x2", chart_width)
                        .attr("y2",y_scale(d)+y_bandwidth/2)
                        .attr("stroke",support_lines_color)
                        .attr("stroke-width",support_lines_width+"px")
                        .attr("stroke-dasharray",support_lines_dashed=="yes"?20:0);
                });
            }


            let bubbles = chart.append('g')
                .classed("bubbles-group",true);

            bubbles.selectAll('circle')
                .data(data.rows)
                .enter()
                .append('circle')
                .attr("class",(d)=>'circle-'+d[1])
                .attr('cx', (d)=>x_scale(d[0])+r_max * 1.5)
                .attr('cy', (d)=>{
                    let y = y_scale(d[1])+y_bandwidth/2;
                    return y;
                })
                .attr('r', (d)=>radius_scale(d[2]))
                .attr('fill', (d)=>color(d[2]))
                .on('mouseover', mouseover)
                .on('mouseout', mouseout)
                .on('mousemove', mousemove);


            chart.append('g')
                .classed("x-axis",true)
                .attr("transform",`translate(${r_max * 1.5},${chart_height})`)
                .call(x_axis);

            chart.append('g')
                .classed("y-axis",true)
                .attr("transform",`translate(0,0)`)
                .call(y_axis);




            function mouseover(d){

                d3.select(this).classed('highlighted',true).classed('arc',false);


                var init = function(selection){
                    //console.log('selection:',selection);
                    selection.each(function(d){
                        //console.log(d.index);
                        let i = d.index;
                        d3.select(this)
                            .attr('class', 'tooltip-container');
                            //.style('width', 300 + 'px');
                        // Tooltip Title
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-title')
                            .text('Info');

                        // Tooltip Content
                        if(data.fields.length>=4)
                        {
                            d3.select(this).append('p')
                                .attr('class', 'tooltip-content')
                                .html(data.fields[0].name + ' : ' + d[0] + '</br>'
                                    + data.fields[1].name + ' : ' + d[1] + '</br>'
                                    + data.fields[2].name + ' : ' + d[2] + '</br>'
                                    + data.fields[3].name + ' : ' + d[3] + '</br>');
                        }
                        else {
                            d3.select(this).append('p')
                                .attr('class', 'tooltip-content')
                                .html(data.fields[0].name + ' : ' + d[0] + '</br>'
                                    + data.fields[1].name + ' : ' + d[1] + '</br>'
                                    + data.fields[2].name + ' : ' + d[2] + '</br>');
                        }


                    });
                };

                var tooltipContainer = d3.select('body').append('div')
                    .datum(d)
                    .attr('class','tooltip-container')
                    .call(init);

                tooltipContainer.style('left', (d3.event.pageX ) + 'px')
                    .style('top', (d3.event.pageY ) + 'px');


            }
            function mousemove(d){
                //let mouse = d3.mouse(this);

                //d3.select('#tooltip').attr('transform',`translate(${mouse[0]-20},${mouse[1]-20})`);
                d3.select('div.tooltip-container').style('left', (d3.event.pageX ) + 'px')
                    .style('top', (d3.event.pageY ) + 'px');


                //console.log(d3.mouse(this));
            }
            function mouseout(d){
                d3.select(this).classed('arc',true).classed('highlighted',false);
                //d3.select('#tooltip').remove();
                d3.select('div.tooltip-container').remove();
            }




        },

        // Search data params
        getInitialDataParams: function() {
            return ({
                outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
                count: 10000
            });
        },

        // Override to respond to re-sizing events
        reflow: function() {}
    });
});
