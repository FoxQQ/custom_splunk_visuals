/*
 * Visualization source
 */
define([
            'jquery',
            'underscore',
            'api/SplunkVisualizationBase',
            'api/SplunkVisualizationUtils',
            'd3'
            // Add required assets to this list
        ],
        function(
            $,
            _,
            SplunkVisualizationBase,
            vizUtils,
            d3
        ) {
  
    // Extend from SplunkVisualizationBase
    return SplunkVisualizationBase.extend({
  
        initialize: function() {
            SplunkVisualizationBase.prototype.initialize.apply(this, arguments);
            this.$el = $(this.el);

            this.$el.append('<h3>Chart Header</h3>');
            this.$el.addClass('my-pie-chart');
            
            // Initialization logic goes here
        },

        // Optionally implement to format data returned from search. 
        // The returned object will be passed to updateView as 'data'
        formatData: function(data) {

            // Format data 
                //console.log('data in format data:');
            /*
            data=data.rows;
                let vals=[],logs=[];
                for(let row in data){
                    //console.log(data[row]);
                    logs.push(data[row][0]);
                    vals.push(data[row][1]);
                }
                logs.pop();
                vals.pop();

                //console.log(data);
            return vals;
            */
            return data
        },
  
        // Implement updateView to render a visualization.
        //  'data' will be the data object returned from formatData or from the search
        //  'config' will be the configuration property object
        updateView: function(data, config) {
		    //console.log('update view variables:');
            //console.log('config',config);
		    //console.log('data',data);
		    var data = data;
		    let values = [];
		    var sum_=0;
		    for (let i=0;i<data.rows.length;i++){
                let val=Number(data.rows[i][1]);
                sum_+=val;
		        values.push(val);

            }
            let svg_width=this.$el.width(),svg_height=this.$el.height();
            this.$el.empty();
            //console.log(this.el);
            // Draw something here
            //let y= this.$el.height();
            let outerRadius = parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'outerRadius']) || 250;
            let innerRadius = parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'innerRadius']) || 0;
            let sumtext = config[this.getPropertyNamespaceInfo().propertyNamespace + 'sumtext'] || 'yes';
            let sumunit = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'sumunit']) || "";
            let sumlink = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'sumlink']) || "#";

            let r = outerRadius;

            let color = d3.scaleOrdinal().range(d3.schemeDark2);


            let svg = d3.select(this.el)
                .append('svg')
                .attr('id','chart')
                .attr('width','100%')
                .attr('height','100%');

           
            console.log("w/h",svg_width,svg_height);
            let chart = svg.append('g')
                .attr('transform','translate('+svg_width/2+','+svg_height/2+')');
            r=r-2;

            let pie_generator = d3.pie().sort(null)
                .value((d)=>{
                    return d;
                });

            let arc = d3.arc()
                .outerRadius(r)
                .innerRadius(innerRadius);

            chart.selectAll('path')
                .data(pie_generator(values))
                .enter()
                .append('path')
                .attr('d',arc)
                .attr('fill',(d)=>{
                    return color(d.value);
                })
                .attr('class',(d,i)=>{return 'arc_'+data.rows[i][0];})
                .on('mouseover',mouseover)
                .on('mousemove',mousemove)
                .on('mouseout',mouseout);

            if(sumtext=='yes'){
                let textgroup = svg.append('g')
                let textlink = textgroup.append('a');

                textlink.append('text')
                    .text(sum_+' '+sumunit)
                    .style('font-wheight','bold')
                    .style('font-size',innerRadius/2+'px');

                let widthSumtext = textgroup.node().getBBox().width,
                    heightSumtext = textgroup.node().getBBox().height;
                console.log(widthSumtext);
                textgroup.remove();
                textgroup = svg.append('g')
                    .attr('transform',`translate(${svg_width/2-widthSumtext/2},${svg_height/2+heightSumtext/2})`);
                textlink = textgroup.append('a')
                    .attr('class','single-drilldown')
                    .attr('href','#');

                textlink.append('text')
                    .text(sum_+' '+sumunit)
                    .style('font-wheight','bold')
                    .style('fill','#333')
                    .style('font-size', innerRadius/2+'px');

            }

            function mouseover(d){

                d3.select(this).classed('highlighted',true).classed('arc',false);


                var init = function(selection){
                    //console.log('selection:',selection);
                    selection.each(function(d){
                        //console.log(d.index);
                        let i = d.index;
                        d3.select(this)
                            .attr('class', 'tooltip-container');
                            //.style('width', 300 + 'px');
                        // Tooltip Title
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-title')
                            .text('Info');

                        // Tooltip Content
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-content')
                            .html(data.fields[0].name + ' : ' + data.rows[i][0] + '</br>'
                                + data.fields[1].name + ' : ' + data.rows[i][1] + '</br>'
                                + 'Percentage' + ' : ' + (parseFloat(data.rows[i][1])*100/sum_).toFixed(2)+'%');

                    });
                };

                var tooltipContainer = d3.select('body').append('div')
                    .datum(d)
                    .attr('class','tooltip-container')
                    .call(init);

                tooltipContainer.style('left', (d3.event.pageX ) + 'px')
                    .style('top', (d3.event.pageY ) + 'px');


            }
            function mousemove(d){
                //let mouse = d3.mouse(this);

                //d3.select('#tooltip').attr('transform',`translate(${mouse[0]-20},${mouse[1]-20})`);
                d3.select('div.tooltip-container').style('left', (d3.event.pageX ) + 'px')
                    .style('top', (d3.event.pageY ) + 'px');


                //console.log(d3.mouse(this));
            }
            function mouseout(d){
                d3.select(this).classed('arc',true).classed('highlighted',false);
                //d3.select('#tooltip').remove();
                d3.select('div.tooltip-container').remove();
            }




        },

        // Search data params
        getInitialDataParams: function() {
            return ({
                outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
                count: 10000
            });
        },

        // Override to respond to re-sizing events
        reflow: function() {}
    });
});
