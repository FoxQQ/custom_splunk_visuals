/*
 * Visualization source
 */
define([
            'jquery',
            'underscore',
            'api/SplunkVisualizationBase',
            'api/SplunkVisualizationUtils',
            'd3'
            // Add required assets to this list
        ],
        function(
            $,
            _,
            SplunkVisualizationBase,
            vizUtils,
            d3
        ) {
  
    // Extend from SplunkVisualizationBase
    return SplunkVisualizationBase.extend({
  
        initialize: function() {
            SplunkVisualizationBase.prototype.initialize.apply(this, arguments);
            this.$el = $(this.el);

            this.$el.append('<h3>Chart Header</h3>');
            this.$el.addClass('my-pie-chart');
            
            // Initialization logic goes here
        },

        // Optionally implement to format data returned from search. 
        // The returned object will be passed to updateView as 'data'
        formatData: function(data) {

            // Format data 
                //console.log('data in format data:');
            /*
            data=data.rows;
                let vals=[],logs=[];
                for(let row in data){
                    //console.log(data[row]);
                    logs.push(data[row][0]);
                    vals.push(data[row][1]);
                }
                logs.pop();
                vals.pop();

                //console.log(data);
            return vals;
            */
            return data
        },
  
        // Implement updateView to render a visualization.
        //  'data' will be the data object returned from formatData or from the search
        //  'config' will be the configuration property object
        updateView: function(data, config) {
		    //console.log('update view variables:');
            //console.log('config',config);
		    //console.log('data',data);
		    var data = data;
		    //console.log("data,",data.rows);
		    var lastrow = data.rows.pop();

		    if(typeof lastrow!=="undefined"){
		        console.log("pop",lastrow[0]);
            }
            //console.log("data after pop",data.rows);
		    let values = [];
		    var sum_=0;
		    for (let i=0;i<data.rows.length;i++){
                let val=Number(data.rows[i][1]);
                sum_+=val;
		        values.push(val);

            }
            let svg_width=this.$el.width(),svg_height=this.$el.height();
            //console.log("w/h:",svg_width, svg_height)

		    this.$el.empty();
            ///reading options from the webform
            ///general
            let headertext_size=parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'headertext_size']) || 32;
            ///trend

            ///pie
            let innerRadius = parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'innerRadius']) || 0;
            let sumtext = config[this.getPropertyNamespaceInfo().propertyNamespace + 'sumtext'] || 'yes';
            let sumunit = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'sumunit']) || "";
            let sumlink = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'sumlink']) || "#";
            let customtextflag = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'customtextflag']) || "no";
            let customtext = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'customtext']) || "";
            let sumtextsize = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'sumtextsize']) || "32";

            svg_height= parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'svg_height']) || svg_height;


            let color = d3.scaleOrdinal().range(d3.schemeDark2);
            let padding = 10;

            let svg = d3.select(this.el)
                .append('svg')
                .attr('id','chart')
                .attr('width','100%')
                .attr('height','100%');
            let border_width=2;
            let box_x = border_width + padding,
                box_width = svg_width - border_width - padding*2,
                chart_height = svg_height-border_width - headertext_size - 10 - padding*2,
                header_height = border_width + headertext_size+10;
            r = chart_height/2<box_width/4?(chart_height/2):(box_width/4);
            /////drawing the two big boxes
            let boxgroup = svg.append('g').attr('class','boxgroup');
            boxgroup.append('rect')
                .attr("x",box_x)
                .attr("y",border_width + padding)
                .attr("width", box_width)
                .attr("height", header_height)
                .attr("fill","red")
                .attr("stroke","#000000")
                .attr("stroke-width","1.5px");

            boxgroup.append("rect")
                .attr("x",box_x)
                .attr("y", border_width + padding + header_height)
                .attr("width", box_width)
                .attr("height", chart_height)
                .attr("fill","#ffffff")
                .attr("stroke","#000000")
                .attr("stroke-width","1.5px");
            //support lines .....
            boxgroup.append('line')
                .attr("stroke","black")
                .attr("x1", box_x + box_width/2)
                .attr("x2", box_x + box_width/2)
                .attr("y1", border_width + padding + header_height)
                .attr("y2", border_width + padding + header_height + chart_height);
            /*
            boxgroup.append('line')
                .attr("stroke","black")
                .attr("x1", box_x + box_width/4)
                .attr("x2", box_x + box_width/4)
                .attr("y1", border_width + padding + header_height)
                .attr("y2", border_width + padding + header_height + chart_height);
            boxgroup.append('line')
                .attr("stroke","black")
                .attr("x1", box_x + box_width*3/4)
                .attr("x2", box_x + box_width*3/4)
                .attr("y1", border_width + padding + header_height)
                .attr("y2", border_width + padding + header_height + chart_height);
            */

            /////////HEADER Text////////////////////////////////////////////////////////////////////////
            let textgroup = boxgroup.append('g');
            let textlink = textgroup.append('a');

            textlink.append('text')
                .text("TEXTEXTTEXT")
                .style('font-wheight','bold')
                .style('font-size',headertext_size+'px');

            let widthSumtext = textgroup.node().getBBox().width,
                heightSumtext = textgroup.node().getBBox().height;

            textgroup.remove();
            textgroup = boxgroup.append('g')
                .attr('id','header-text').attr("transform",`translate(${box_width/2-widthSumtext/2},${header_height + padding + border_width - heightSumtext/4})`);
            textlink = textgroup.append('a')
                .attr('class','single-drilldown')
                .attr('href',sumlink);


            textlink.append('text')
                .text("TEXTEXTEXTEXT")
                .style('font-wheight','bold')
                .style('fill','#333')
                .style('font-size', headertext_size+'px');



            ///////////////PIE CHART//////////////////////////////////////////////////////////////////////
            //console.log("w/h",svg_width,svg_height);
            let chart = svg.append('g')
                .attr('transform','translate('+(box_x+box_width*3/4)+','+ (border_width + padding + header_height +chart_height/2) +')');
            r=r-border_width*2 - border_width;
            let pie_generator = d3.pie().sort(null)
                .value((d)=>{
                    return d;
                });

            let arc = d3.arc()
                .outerRadius(r)
                .innerRadius(innerRadius);

            chart.selectAll('path')
                .data(pie_generator(values))
                .enter()
                .append('path')
                .attr('d',arc)
                .attr('fill',(d,i)=>{
                    return color(i);
                })
                .attr('class',(d,i)=>{return 'arc_'+data.rows[i][0];})
                .on('mouseover',mouseover)
                .on('mousemove',mousemove)
                .on('mouseout',mouseout);

            if(sumtext=='yes'){
                let textgroup = chart.append('g')
                let textlink = textgroup.append('a');

                textlink.append('text')
                    .text(customtextflag=="no"?sum_+' '+sumunit:customtext)
                    .style('font-wheight','bold')
                    .style('font-size',sumtextsize+'px');

                let widthSumtext = textgroup.node().getBBox().width,
                    heightSumtext = textgroup.node().getBBox().height;

                textgroup.remove();
                textgroup = chart.append('g').attr("transform",`translate(${-widthSumtext/2},${heightSumtext/3})`);;
                textlink = textgroup.append('a')
                    .attr('class','single-drilldown')
                    .attr('href',sumlink);


                textlink.append('text')
                    .text(customtextflag=="no"?sum_+' '+sumunit:customtext)
                    .style('font-wheight','bold')
                    .style('fill','#333')
                    .style('font-size', sumtextsize+'px');

            }
            

            ////TREND ///////////////////////////////////////////////////////////////////
            if(typeof lastrow!=="undefined") {
                let trend_text_content = lastrow[1];

                let trend = svg.append('g').attr('id', "trend-group")
                    .attr('transform', 'translate(' + (box_x + box_width / 4) + ',' + (border_width + padding + header_height + chart_height / 2) + ')');
                /////ARROW//////////////////////
                let indicator_group = trend.append("g").attr("transform", "translate(" + 0 + "," + 0 + ")").attr('id', 'trend-arrowgroup');
                let arrow_len = 100,
                    arrow_size = 60;
                //let up = Math.round(Math.random());
                if (trend_text_content<0) {
                    let arrow = indicator_group.append("path")
                        .attr("d", `M 0 ${-arrow_size / 4} L ${arrow_len * 2 / 3} ${-arrow_size / 4} L ${arrow_len * 2 / 3} ${-arrow_size / 2} L ${arrow_len} 0 L ${arrow_len * 2 / 3} ${arrow_size / 2} L ${arrow_len * 2 / 3} ${arrow_size / 4} L 0 ${arrow_size / 4} L 0 0`)
                        .attr("fill", "green")
                        .attr("transform", "rotate(45)");
                    let arrow_box = arrow.node().getBoundingClientRect();
                    let arrow_height = arrow_box.bottom - arrow_box.top,
                        arrow_width = arrow_box.right - arrow_box.left;
                    arrow.attr("transform", "translate(" + -arrow_width / 4 + "," + -arrow_height / 2 + ") rotate(45)");

                }
                else {
                    let arrow = indicator_group.append("path")
                        .attr("d", `M 0 ${-arrow_size / 4} L ${arrow_len * 2 / 3} ${-arrow_size / 4} L ${arrow_len * 2 / 3} ${-arrow_size / 2} L ${arrow_len} 0 L ${arrow_len * 2 / 3} ${arrow_size / 2} L ${arrow_len * 2 / 3} ${arrow_size / 4} L 0 ${arrow_size / 4} L 0 0`)
                        .attr("fill", "red")
                        .attr("transform", `rotate(-45)`);
                    let arrow_box = arrow.node().getBoundingClientRect();
                    let arrow_height = arrow_box.bottom - arrow_box.top,
                        arrow_width = arrow_box.right - arrow_box.left;
                    arrow.attr("transform", `translate(${-arrow_width / 4},0) rotate(-45) `);
                }

                ////////////TEXT/////////////
                let trend_textgroup = trend.append('g').attr('id', 'trend-textgroup');



                let trend_text = trend_textgroup.append('text')
                    .text(trend_text_content)
                    .attr("font-size", heightSumtext + "px");
                let textwidth = trend_text.node().getBBox().width, textheight = trend_text.node().getBBox().height;
                trend_text.remove();
                trend_text = trend_textgroup.append("text")
                    .text(trend_text_content)
                    .attr("font-size", heightSumtext + "px")
                    .attr("transform", `translate(${-textwidth / 2},${chart_height / 4})`);
            }




            function mouseover(d){

                d3.select(this).classed('highlighted',true).classed('arc',false);


                var init = function(selection){
                    //console.log('selection:',selection);
                    selection.each(function(d){
                        //console.log(d.index);
                        let i = d.index;
                        d3.select(this)
                            .attr('class', 'tooltip-container');
                            //.style('width', 300 + 'px');
                        // Tooltip Title
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-title')
                            .text('Info');

                        // Tooltip Content
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-content')
                            .html(data.fields[0].name + ' : ' + data.rows[i][0] + '</br>'
                                + data.fields[1].name + ' : ' + data.rows[i][1] + '</br>'
                                + 'Percentage' + ' : ' + (parseFloat(data.rows[i][1])*100/sum_).toFixed(2)+'%');

                    });
                };

                var tooltipContainer = d3.select('body').append('div')
                    .datum(d)
                    .attr('class','tooltip-container')
                    .call(init);

                tooltipContainer.style('left', (d3.event.pageX ) + 'px')
                    .style('top', (d3.event.pageY ) + 'px');


            }
            function mousemove(d){
                //let mouse = d3.mouse(this);

                //d3.select('#tooltip').attr('transform',`translate(${mouse[0]-20},${mouse[1]-20})`);
                d3.select('div.tooltip-container').style('left', (d3.event.pageX ) + 'px')
                    .style('top', (d3.event.pageY ) + 'px');


                //console.log(d3.mouse(this));
            }
            function mouseout(d){
                d3.select(this).classed('arc',true).classed('highlighted',false);
                //d3.select('#tooltip').remove();
                d3.select('div.tooltip-container').remove();
            }




        },

        // Search data params
        getInitialDataParams: function() {
            return ({
                outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
                count: 10000
            });
        },

        // Override to respond to re-sizing events
        reflow: function() {}
    });
});
