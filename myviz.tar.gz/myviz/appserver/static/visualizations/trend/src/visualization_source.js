/*
 * Visualization source
 */
define([
            'jquery',
            'underscore',
            'api/SplunkVisualizationBase',
            'api/SplunkVisualizationUtils',
            'd3'
            // Add required assets to this list
        ],
        function(
            $,
            _,
            SplunkVisualizationBase,
            vizUtils,
            d3
        ) {
  
    // Extend from SplunkVisualizationBase
    return SplunkVisualizationBase.extend({
  
        initialize: function() {
            SplunkVisualizationBase.prototype.initialize.apply(this, arguments);
            this.$el = $(this.el);

            this.$el.append('<h3>The input data seems not to be in the correct format. You need 2 columns: 1. naming, 2. values; The last entry is used to generate the trend arrow and value.</h3>');
            this.$el.addClass('my-pie-chart');
            
            // Initialization logic goes here
        },

        // Optionally implement to format data returned from search. 
        // The returned object will be passed to updateView as 'data'
        formatData: function(data) {

            // Format data 
                //console.log('data in format data:');
            /*
            data=data.rows;
                let vals=[],logs=[];
                for(let row in data){
                    //console.log(data[row]);
                    logs.push(data[row][0]);
                    vals.push(data[row][1]);
                }
                logs.pop();
                vals.pop();

                //console.log(data);
            return vals;
            */
            return data
        },
  
        // Implement updateView to render a visualization.
        //  'data' will be the data object returned from formatData or from the search
        //  'config' will be the configuration property object
        updateView: function(data, config) {
		    //console.log('update view variables:');
            //console.log('config',config);
		    //console.log('data',data);

		    //console.log("data,",data.rows);
            if(data.rows.length>1){

                var lastrow = data.rows[data.rows.length-1];

                data.rows=data.rows.slice(0, data.rows.length-1);
                //console.log("Data:", data);
                //console.log("Trend:", lastrow);

            }
            else{
                console.log("no data");

            }
            //console.log("data after pop",data.rows);
		    let values = [];
		    var sum_=0;
		    for (let i=0;i<data.rows.length;i++){
                let val=Number(data.rows[i][1]);
                sum_+=val;
		        values.push(val);

            }
            let svg_width=this.$el.width(),svg_height=this.$el.height();
            //console.log("w/h:",svg_width, svg_height)

		    this.$el.empty();
            ///reading options from the webform
            ///header

            let headertext_size=parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'headertext_size']) || 18;
            svg_height= parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'svg_height']) || svg_height;
            let border_width=parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'border_width']) || 1;
            let border_color=(config[this.getPropertyNamespaceInfo().propertyNamespace + 'border_color']) || "#cccccc";
            let headertext=(config[this.getPropertyNamespaceInfo().propertyNamespace + 'headertext']) || "None";
            let headertext_color=(config[this.getPropertyNamespaceInfo().propertyNamespace + 'headertext_color']) || "#000000";
            let headerbox_color=(config[this.getPropertyNamespaceInfo().propertyNamespace + 'headerbox_color']) || "#ffffff";
            let box_edges=parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'box_edges']) || 10;
            ///trend

            let arrow_down_color = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'arrow_down_color']) || "#ffaaaa";
            let arrow_up_color = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'arrow_up_color']) || "#aaffaa";
            let trendtextsize = parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'trendtextsize']) || 32;
            let trendtext_color = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'trendtext_color']) || "#000000";
            let arrow_length = parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'arrow_length']) || 60,
                arrow_width= parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'arrow_width']) || 20;
            let sumlink = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'sumlink']) || "#";
            let sumunit = (config[this.getPropertyNamespaceInfo().propertyNamespace + 'sumunit']) || "";
            let round_digits = parseInt(config[this.getPropertyNamespaceInfo().propertyNamespace + 'round_digits']) || 0;


            let color = d3.scaleOrdinal().range(d3.schemeDark2);
            let padding = 10;

            let svg = d3.select(this.el)
                .append('svg')
                .attr('id','chart')
                .attr('width','100%')
                .attr('height','100%');
            let box_x = border_width + padding,
                box_width = svg_width - border_width - padding*2,
                chart_height = svg_height-border_width - headertext_size - 10 - padding*2,
                header_height = border_width + headertext_size+10;
            r = chart_height/2<box_width/4?(chart_height/2):(box_width/4);
            /////drawing the two big boxes
            let boxgroup = svg.append('g').attr('class','boxgroup');
            boxgroup.append('rect')
                .classed("header-box",true)
                .attr("x",box_x)
                .attr("y",border_width + padding)
                .attr("rx",box_edges+"px")
                .attr("ry", box_edges+"px")
                .attr("width", box_width)
                .attr("height", header_height*2)
                .attr("fill",headerbox_color)
                .attr("stroke",border_color)
                .attr("stroke-width",border_width+"px");

            boxgroup.append("rect")
                .classed("chart-box",true)
                .attr("x",box_x)
                .attr("y", border_width + padding + header_height)
                .attr("rx",box_edges+"px")
                .attr("ry", box_edges+"px")
                .attr("width", box_width)
                .attr("height", chart_height)
                .attr("fill","#ffffff")
                .attr("stroke",border_color)
                .attr("stroke-width",border_width+"px");
            //support lines .....
            /*
            boxgroup.append('line')
                .classed("chart-split-line",true)
                .attr("stroke","black")
                .attr("x1", box_x + box_width/2)
                .attr("x2", box_x + box_width/2)
                .attr("y1", border_width + padding + header_height)
                .attr("y2", border_width + padding + header_height + chart_height);

            boxgroup.append('line')
                .attr("stroke","black")
                .attr("x1", box_x + box_width/4)
                .attr("x2", box_x + box_width/4)
                .attr("y1", border_width + padding + header_height)
                .attr("y2", border_width + padding + header_height + chart_height);
            boxgroup.append('line')
                .attr("stroke","black")
                .attr("x1", box_x + box_width*3/4)
                .attr("x2", box_x + box_width*3/4)
                .attr("y1", border_width + padding + header_height)
                .attr("y2", border_width + padding + header_height + chart_height);
            */

            /////////HEADER Text////////////////////////////////////////////////////////////////////////
            let textgroup = boxgroup.append('g');
            let textlink = textgroup.append('a');

            textlink.append('text')
                .text(headertext)
                .style('font-wheight','bold')
                .style('font-size',headertext_size+'px');

            let widthSumtext = textgroup.node().getBBox().width,
                heightSumtext = textgroup.node().getBBox().height;

            textgroup.remove();
            textgroup = boxgroup.append('g')
                .attr('id','header-text').attr("transform",`translate(${box_width/2-widthSumtext/2},${header_height + padding + border_width - heightSumtext/4})`);
            textlink = textgroup.append('a')
                .attr('class','single-drilldown')
                .attr('href',sumlink);


            textlink.append('text')
                .classed("header-text",true)
                .text(headertext)
                .style('font-wheight','bold')
                .style('fill',headertext_color)
                .style('font-size', headertext_size+'px');






            ////TREND ///////////////////////////////////////////////////////////////////
            if(typeof lastrow!=="undefined") {
                let trend_text_content = (sum_ - parseFloat(lastrow[1]));
                if(round_digits>0){
                    trend_text_content=trend_text_content.toFixed(round_digits);
                }

                let trend = svg.append('g').attr('id', "trend-group")
                    .attr('transform', 'translate(' + (box_x + box_width / 2) + ',' + (border_width + padding + header_height + chart_height / 2) + ')');
                /////ARROW//////////////////////
                let indicator_group = trend.append("g").attr("transform", "translate(" + -arrow_length/2 + "," + 0 + ")").attr('id', 'trend-arrowgroup');
                let tetxt_trend_sum_scale=4/7;
                if(trend_text_content<0){

                indicator_group.append('line')
                    .classed("arrow", true)
                    .attr("stroke",arrow_down_color)
                    .attr("stroke-width",arrow_width+"px")
                    .attr("x1",-arrow_length/2 )
                    .attr("y1",0)
                    .attr("x2", arrow_length/2 + arrow_width/2)
                    .attr("y2",0);

                indicator_group.append('line')
                    .classed("arrow", true)
                    .attr("stroke",arrow_down_color)
                    .attr("stroke-width",arrow_width+"px")
                    .attr("x1",arrow_length/2)
                    .attr("y1", -arrow_length)
                    .attr("x2", arrow_length/2)
                    .attr("y2",0);

                indicator_group.append('line')
                    .classed("arrow", true)
                    .attr("stroke",arrow_down_color)
                    .attr("stroke-width",arrow_width+"px")
                    .attr("x1",-arrow_length/2)
                    .attr("y1", -arrow_length)
                    .attr("x2", arrow_length/2)
                    .attr("y2",0);

                    indicator_group.append("text")
                        .classed("trend-subtext",true)
                        .text(sum_+" "+sumunit)
                        .attr('fill', trendtext_color)
                        .attr("font-size", trendtextsize*tetxt_trend_sum_scale + "px")
                        .attr("transform", `translate(${(arrow_length / 2)+arrow_width},${(trendtextsize*tetxt_trend_sum_scale)/2})`);

                } else {
                    indicator_group.append('line')
                        .classed("arrow", true)
                        .attr("stroke",arrow_up_color)
                        .attr("stroke-width",arrow_width+"px")
                        .attr("x1",-arrow_length/2 )
                        .attr("y1",-arrow_length)
                        .attr("x2", arrow_length/2 + arrow_width/2)
                        .attr("y2",-arrow_length);

                    indicator_group.append('line')
                        .classed("arrow", true)
                        .attr("stroke",arrow_up_color)
                        .attr("stroke-width",arrow_width+"px")
                        .attr("x1",arrow_length/2)
                        .attr("y1", -arrow_length)
                        .attr("x2", arrow_length/2)
                        .attr("y2",0);

                    indicator_group.append("text")
                        .classed("trend-subtext",true)
                        .text(sum_+" "+sumunit)
                        .attr('fill', trendtext_color)
                        .attr("font-size", trendtextsize*tetxt_trend_sum_scale + "px")
                        .attr("transform", `translate(${(arrow_length / 2)+arrow_width},${-arrow_length + (trendtextsize*tetxt_trend_sum_scale)/2})`);

                    indicator_group.append('line')
                        .classed("arrow", true)
                        .attr("stroke",arrow_up_color)
                        .attr("stroke-width",arrow_width+"px")
                        .attr("x1",-arrow_length/2)
                        .attr("y1", 0)
                        .attr("x2", arrow_length/2)
                        .attr("y2",-arrow_length);
                }



                ////////////TEXT/////////////

                trend_text_content= "Δ "+trend_text_content;
                let trend_textgroup = trend.append('g').attr('id', 'trend-textgroup');



                let trend_text = trend_textgroup.append('text')
                    .text(trend_text_content+" "+sumunit)
                    .attr("font-size", trendtextsize + "px");
                let textwidth = trend_text.node().getBBox().width, textheight = trend_text.node().getBBox().height;
                trend_text.remove();
                trend_text = trend_textgroup.append("text")
                    .classed("trend-text",true)
                    .text(trend_text_content+" "+sumunit)
                    .attr('fill', trendtext_color)
                    .attr("font-size", trendtextsize + "px")
                    .attr("transform", `translate(${-textwidth / 2},${chart_height / 4})`);


            }



            function mouseover(d){

                d3.select(this).classed('highlighted',true).classed('arc',false);


                var init = function(selection){
                    //console.log('selection:',selection);
                    selection.each(function(d){
                        //console.log(d.index);
                        let i = d.index;
                        d3.select(this)
                            .attr('class', 'tooltip-container');
                            //.style('width', 300 + 'px');
                        // Tooltip Title
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-title')
                            .text('Info');

                        // Tooltip Content
                        d3.select(this).append('p')
                            .attr('class', 'tooltip-content')
                            .html(data.fields[0].name + ' : ' + data.rows[i][0] + '</br>'
                                + data.fields[1].name + ' : ' + data.rows[i][1] + '</br>'
                                + 'Percentage' + ' : ' + (parseFloat(data.rows[i][1])*100/sum_).toFixed(2)+'%');

                    });
                };

                var tooltipContainer = d3.select('body').append('div')
                    .datum(d)
                    .attr('class','tooltip-container')
                    .call(init);

                tooltipContainer.style('left', (d3.event.pageX ) + 'px')
                    .style('top', (d3.event.pageY ) + 'px');


            }
            function mousemove(d){
                //let mouse = d3.mouse(this);

                //d3.select('#tooltip').attr('transform',`translate(${mouse[0]-20},${mouse[1]-20})`);
                d3.select('div.tooltip-container').style('left', (d3.event.pageX ) + 'px')
                    .style('top', (d3.event.pageY ) + 'px');


                //console.log(d3.mouse(this));
            }
            function mouseout(d){
                d3.select(this).classed('arc',true).classed('highlighted',false);
                //d3.select('#tooltip').remove();
                d3.select('div.tooltip-container').remove();
            }




        },

        // Search data params
        getInitialDataParams: function() {
            return ({
                outputMode: SplunkVisualizationBase.ROW_MAJOR_OUTPUT_MODE,
                count: 10000
            });
        },

        // Override to respond to re-sizing events
        reflow: function() {}
    });
});
