require([
    "splunkjs/mvc",
    'jquery',
    'underscore',
    "splunkjs/mvc/tokenutils",
    "splunkjs/mvc/simplexml/ready!"
], function(mvc, tokenutils) {




    console.log("test.js is loaded with info field trigger");


    //infofields
    var info_triggers = $('.info-trigger');
    var info_fields = $('.info-field');
    info_fields.hide();
    console.log(info_triggers);
    info_triggers.click(function (event){
        let target_name = event.target.getAttribute('class').split(" ")[1];
        $(".info-field."+target_name).toggle(1000);

    });




});