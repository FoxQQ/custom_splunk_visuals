require([
    "splunkjs/mvc",
    "splunkjs/mvc/tokenutils",
    "splunkjs/mvc/simplexml/ready!"
], function(mvc, tokenutils) {




    console.log("test.js is loaded");






});