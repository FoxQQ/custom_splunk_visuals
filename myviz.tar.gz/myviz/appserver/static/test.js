require([
    'jquery',
    'underscore',
    "splunkjs/mvc",
    "splunkjs/mvc/tokenutils",
    "splunkjs/mvc/simplexml/ready!"
], function($, _, mvc) {




    console.log("test.js is loaded with info field trigger");


    //infofields
    var info_triggers = $('.info-trigger');
    var info_fields = $('.info-field');
    info_fields.hide();
    info_triggers.click(function (event){
        let target_name = event.target.getAttribute('class').split(" ")[1];
        $(".info-field."+target_name).toggle(1000);

    });

    //////token

    let index_prefix = "index = ";
    let index_delimeter = " OR ";

    let index_values = {
        'div':{
            'status':'true',
            "bla":"asf"
        },
        'de':{
            'status':'true'
        },
        'es':{
            'status':'true'
        },
        'fr':{
            'status':'true'
        },
        'uk':{
            'status':'true'
        }

    };
    let time_values = {
        '7d':{
            'status':'false',
            'search_earliest':'-8d@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-15d@d',
            'trend_latest':'-9d@d'
        },
        '30d':{
            'status':'true',
            'search_earliest':'-31d@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-61d@d',
            'trend_latest':'-32d@d'
        },
        'pm':{
            'status':'false',
            'search_earliest':'-1month@month',
            'search_latest':'@mon',
            'trend_earliest':'-2month@month',
            'trend_latest':'-1month@month'
        },
        '3m':{
            'status':'false',
            'search_earliest':'-91d@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-181d@d',
            'trend_latest':'-92d@d'
        },
        '1y':{
            'status':'false',
            'search_earliest':'-1y@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-2y@d',
            'trend_latest':'-1y@d'
        },
        'all':{
            'status':'false',
            'search_earliest':'0',
            'search_latest':'-1d@d',
            'trend_earliest':'0',
            'trend_latest':'-1d@d'
        }

    };

    var defaultTokenModel = mvc.Components.get("default");
    var submittedTokenModel = mvc.Components.get("submitted");
    var initializeCountryIndex = {'index_Country':get_index_token()};
    /*
    defaultTokenModel.set(initializeCountryIndex);
    submittedTokenModel.set(initializeCountryIndex);

    defaultTokenModel.set({'search_earliest': time_values['30d'].search_earliest});
    submittedTokenModel.set({'search_earliest': time_values['30d'].search_earliest});

    defaultTokenModel.set({'search_latest': time_values['30d'].search_latest});
    submittedTokenModel.set({'search_latest': time_values['30d'].search_latest});


    defaultTokenModel.set({'trend_earliest': time_values['30d'].trend_earliest});
    submittedTokenModel.set({'trend_earliest': time_values['30d'].trend_earliest});

    defaultTokenModel.set({'trend_latest': time_values['30d'].trend_latest});
    submittedTokenModel.set({'trend_latest': time_values['30d'].trend_latest});
*/

    ////add time buttons
    //// tokens are: $search_earliest$ $search_latest$

    console.log(get_index_token(("uk")));
    function get_index_token(index_to_toggle){
        console.log(index_to_toggle);
        let str_ = '',
            first=true;
        if(index_to_toggle != null){
            console.log(index_to_toggle, "or undefined?");
            index_values[index_to_toggle].status = toggle(index_values[index_to_toggle].status);
        }

        for (var property in index_values) {
            if(index_values[property].status=="true"){
                if (first){
                    str_ = index_prefix + property;
                    first=false;
                }
                else{
                    str_ = str_ + index_delimeter + index_prefix + property;
                }
            }
        }

        for ( let i=0;i<index_values.length;i++){
            if(index_values[i].status=="true"){

                if (first){
                    str_ = index_prefix + index_values[i].value;
                    first=false;
                }
                else{
                    str_ = str_ + index_delimeter + index_prefix + index_values[i].value;
                }
            }
        }
        return str_

    }

    function toggle(x){
        if (x=="true"){
            return 'false';
        }
        else{
            return 'true';
        }
    }




    //DEBUGGING
    //console.log(info_triggers);
    //console.log(defaultTokenModel);
    //console.log(submittedTokenModel);
    //console.log(time_values);
    console.log(initializeCountryIndex);
    //console.log(html);


});