require([
    "splunkjs/mvc",
    "splunkjs/mvc/simplexml/ready!"
], function(mvc) {

    //infofields
    var info_triggers = $('.info-trigger');
    var info_fields = $('.info-field');
    info_fields.hide();

    info_triggers.click(function (event){
        let targetname = event.target.getAttribute('class').split(" ")[1];
        $(`.info-field.${targetname}`).toggle(1000);

    });


    //Flaggen ----------------------------------------------
    var defaultTokenModel = mvc.Components.get("default");
    var indexes;

    let indextoken = defaultTokenModel.get("index_Country");
    if (indextoken!=undefined){
        indexes = indextoken.split(" OR ");
    }else { indexes=[];}

    flags(indexes);


    defaultTokenModel.on("change:index_Country",(a,b)=>{
        if (b!=undefined){indexes = b.split(" OR ");}
        else { indexes=[];}

        $('#index').text(b);
        flags(indexes);


    });

    function flags(indexes){
        let has_de = indexes.indexOf("index=de")>-1?"color":"grey";

        let has_div = indexes.indexOf("index=div")>-1?"color":"grey";

        let has_es = indexes.indexOf("index=es")>-1?"color":"grey";

        let has_uk = indexes.indexOf("index=uk")>-1?"color":"grey";

        let has_fr = indexes.indexOf("index=fr")>-1?"color":"grey";

        let str_ = "";

        let img_path=window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':'+window.location.port: '') + "/en-US/static/app/myviz/"

        str_ += "<img src='"+img_path+"de_" + has_de +".png' style='width:20px;height:auto;'/> ";

        str_ += "<img src='"+img_path+"div_" + has_div +".png' style='width:20px;height:auto;'/> ";

        str_ += "<img src='"+img_path+"es_" + has_es +".png' style='width:20px;height:auto;'/> ";

        str_ += "<img src='"+img_path+"uk_" + has_uk +".png' style='width:20px;height:auto;'/> ";

        str_ += "<img src='"+img_path+"fr_" + has_fr +".png' style='width:20px;height:auto;'/> ";

        $('#index').html(str_);
    }

});