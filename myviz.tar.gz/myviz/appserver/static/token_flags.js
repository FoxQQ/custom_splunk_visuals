require([
    'jquery',
    'underscore',
    "splunkjs/mvc",
    "splunkjs/mvc/tokenutils",
    "splunkjs/mvc/simplexml/ready!"
], function($, _, mvc, tokenutils) {




    //infofields
    var info_triggers = $('.info-trigger');
    var info_fields = $('.info-field');
    info_fields.hide();

    info_triggers.click(function (event){
        let target_name = event.target.getAttribute('class').split(" ")[1];
        $(".info-field."+target_name).toggle(1000);

    });



    //////token

    let index_prefix = "index = ";
    let index_delimeter = " OR ";

    let index_values = {
        'div':{
          'status':'true',
            "bla":"asf"
        },
        'de':{
          'status':'true'
        },
        'es':{
            'status':'true'
        },
        'fr':{
            'status':'true'
        },
        'uk':{
            'status':'true'
        }

    };
    let time_values = {
        '7d':{
            'status':'false',
            'search_earliest':'-8d@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-15d@d',
            'trend_latest':'-9d@d'
        },
        '30d':{
            'status':'true',
            'search_earliest':'-31d@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-61d@d',
            'trend_latest':'-32d@d'
        },
        'pm':{
            'status':'false',
            'search_earliest':'-1month@month',
            'search_latest':'@mon',
            'trend_earliest':'-2month@month',
            'trend_latest':'-1month@month'
        },
        '3m':{
            'status':'false',
            'search_earliest':'-91d@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-181d@d',
            'trend_latest':'-92d@d'
        },
        '1y':{
            'status':'false',
            'search_earliest':'-1y@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-2y@d',
            'trend_latest':'-1y@d'
        },
        'all':{
            'status':'false',
            'search_earliest':'0',
            'search_latest':'-1d@d',
            'trend_earliest':'0',
            'trend_latest':'-1d@d'
        }

    };

    var defaultTokenModel = mvc.Components.get("default");
    var submittedTokenModel = mvc.Components.get("submitted");
    let initializeCountryIndex = {'index_Country':get_index_token()};
    defaultTokenModel.set(initializeCountryIndex);
    submittedTokenModel.set(initializeCountryIndex);

    defaultTokenModel.set({'search_earliest': time_values['30d'].search_earliest});
    submittedTokenModel.set({'search_earliest': time_values['30d'].search_earliest});

    defaultTokenModel.set({'search_latest': time_values['30d'].search_latest});
    submittedTokenModel.set({'search_latest': time_values['30d'].search_latest});


    defaultTokenModel.set({'trend_earliest': time_values['30d'].trend_earliest});
    submittedTokenModel.set({'trend_earliest': time_values['30d'].trend_earliest});

    defaultTokenModel.set({'trend_latest': time_values['30d'].trend_latest});
    submittedTokenModel.set({'trend_latest': time_values['30d'].trend_latest});


    ////add time buttons
    //// tokens are: $search_earliest$ $search_latest$

    let time_ranges = ['7d', '30d','pm', '3m', '1y', 'all'];
    let html="<ul class='custom-ul'>";
    for (let i=0;i<time_ranges.length;i++){
        html += "<li class='custom-li'><button "+ (time_ranges[i]=='30d'?'style="background:#011751;color:#fff;"':"style='background:#fff;color:#011751'") +" class='custom-button time-button' id='"+time_ranges[i]+"'>"+time_ranges[i]+"</button></li>";
    }
    html+="</ul>";
    $('#time_buttons').html(html);

    $('.time-button').on('click',function(event){
        set_timetoken($(event.currentTarget).attr('id'));
    });

    ///add country buttons

    ////put somewhere on the dashboard a div/span/etc. with id="country_buttons"
    //// index token = $index_Country$
    //// <span id="country_buttons"></span>
    let img_path=window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':'+
        window.location.port: '') + "/en-US/static/app/myviz/";

    let indexes = ['div','de','es','fr','uk'];

    html="<ul class='custom-ul'>";
    for (let i=0;i<indexes.length;i++){
        html += "<li class='custom-li'><img class='button custom-button' id='"+indexes[i]+"_btn' src='"+img_path+indexes[i]+"_" + "color.png'/></li>";
    }
    html+="</ul>";
    $('#country_buttons').html(html);

    ////token models


    let div_btn = $('#div_btn');
    let de_btn = $('#de_btn');
    let es_btn = $('#es_btn');
    let fr_btn = $('#fr_btn');
    let uk_btn = $('#uk_btn');

    function click_event_country_btn(event, btn, idx){
        let changeindex = {'index_Country':get_index_token(idx)};
        defaultTokenModel.set(changeindex);
        submittedTokenModel.set(changeindex);
        let img_str = img_path + idx +"_" + (index_values[idx].status=='true'?'color':'grey') +".png";
        $(btn).attr("src",img_str );
    }

    div_btn.on('click',function(event){
        click_event_country_btn(event, this, 'div')
    });
    de_btn.on('click',function(event){
        click_event_country_btn(event,this, 'de')
    });
    es_btn.on('click',function(event){
        click_event_country_btn(event,this, 'es')
    });
    fr_btn.on('click',function(event){
        click_event_country_btn(event,this, 'fr')
    });
    uk_btn.on('click',function(event){
        click_event_country_btn(event,this, 'uk')
    });

    function toggle(x){
        if (x=="true"){
            return 'false';
        }
        else{
            return 'true';
        }
    }

    function set_timetoken(time_range){

        for (var prop in time_values){


            if(time_values[prop].status=="true"){
                time_values[prop].status="false";
                $('#'+prop).attr("style","background:#fff;color:#011751");
            }
        }
        time_values[time_range].status="true";
        $('#'+time_range).attr("style","background:#011751;color:#fff");
        defaultTokenModel.set({'search_earliest': time_values[time_range].search_earliest});
        submittedTokenModel.set({'search_earliest': time_values[time_range].search_earliest});

        defaultTokenModel.set({'search_latest': time_values[time_range].search_latest});
        submittedTokenModel.set({'search_latest': time_values[time_range].search_latest});


        defaultTokenModel.set({'trend_earliest': time_values[time_range].trend_earliest});
        submittedTokenModel.set({'trend_earliest': time_values[time_range].trend_earliest});

        defaultTokenModel.set({'trend_latest': time_values[time_range].trend_latest});
        submittedTokenModel.set({'trend_latest': time_values[time_range].trend_latest});



    }

    function get_index_token(index_to_toggle=null){

        let str_ = '',
        first=true;
        if(index_to_toggle != null){
            index_values[index_to_toggle].status = toggle(index_values[index_to_toggle].status);
        }

        for (var property in index_values) {
            if(index_values[property].status=="true"){
                if (first){
                    str_ = index_prefix + property;
                    first=false;
                }
                else{
                    str_ = str_ + index_delimeter + index_prefix + property;
                }
            }
        }

        for ( let i=0;i<index_values.length;i++){
            if(index_values[i].status=="true"){

                if (first){
                    str_ = index_prefix + index_values[i].value;
                    first=false;
                }
                else{
                    str_ = str_ + index_delimeter + index_prefix + index_values[i].value;
                }
            }
        }
        return str_

    }




/*
    //flags ----------------------------------------------
    //to display token status from splunk native input token
    var defaultTokenModel = mvc.Components.get("default");

    var indexes;

    let indextoken = defaultTokenModel.get("index_Country");
    if (indextoken!=undefined){
        indexes = indextoken.split(" OR ");
    }else { indexes=[];}

    flags(indexes);


    defaultTokenModel.on("change:index_Country",(a,b)=>{
        if (b!=undefined){indexes = b.split(" OR ");}
        else { indexes=[];}

        $('#index').text(b);
        flags(indexes);


    });

    function flags(indexes){
        let has_de = indexes.indexOf("index=de")>-1?"color":"grey";

        let has_div = indexes.indexOf("index=div")>-1?"color":"grey";

        let has_es = indexes.indexOf("index=es")>-1?"color":"grey";

        let has_uk = indexes.indexOf("index=uk")>-1?"color":"grey";

        let has_fr = indexes.indexOf("index=fr")>-1?"color":"grey";

        let str_ = "";

        let img_path=window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':'+
            window.location.port: '') + "/en-US/static/app/myviz/"

        str_ += "<img src='"+img_path+"de_" + has_de +".png' style='width:20px;height:auto;'/> ";

        str_ += "<img src='"+img_path+"div_" + has_div +".png' style='width:20px;height:auto;'/> ";

        str_ += "<img src='"+img_path+"es_" + has_es +".png' style='width:20px;height:auto;'/> ";

        str_ += "<img src='"+img_path+"uk_" + has_uk +".png' style='width:20px;height:auto;'/> ";

        str_ += "<img src='"+img_path+"fr_" + has_fr +".png' style='width:20px;height:auto;'/> ";

        $('#index').html(str_);
    }
*/
});