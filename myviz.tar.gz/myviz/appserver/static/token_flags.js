require([
    'jquery',
    'underscore',
    "splunkjs/mvc",
    "splunkjs/mvc/tokenutils",
    "splunkjs/mvc/simplexml/ready!"
], function($, _, mvc) {

    //console.log("test.js is loaded with info field trigger");

    //infofields
    var info_triggers = $('.info-trigger');
    var info_fields = $('.info-field');
    info_fields.hide();
    info_triggers.click(function (event){
        let target_name = event.target.getAttribute('class').split(" ")[1];
        $(".info-field."+target_name).toggle(1000);

    });

    //////token

    let index_prefix = "index = ";
    let index_delimeter = " OR ";

    let index_values = {
        'div':{
            'status':'true'
        },
        'de':{
            'status':'true'
        },
        'es':{
            'status':'true'
        },
        'fr':{
            'status':'true'
        },
        'uk':{
            'status':'true'
        }

    };
    let time_values = {
        '7d':{
            'status':'false',
            'search_earliest':'-8d@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-15d@d',
            'trend_latest':'-9d@d'
        },
        '30d':{
            'status':'true',
            'search_earliest':'-31d@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-61d@d',
            'trend_latest':'-32d@d'
        },
        'pm':{
            'status':'false',
            'search_earliest':'-1month@month',
            'search_latest':'@mon',
            'trend_earliest':'-2month@month',
            'trend_latest':'-1month@month'
        },
        '3m':{
            'status':'false',
            'search_earliest':'-91d@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-181d@d',
            'trend_latest':'-92d@d'
        },
        '1y':{
            'status':'false',
            'search_earliest':'-1y@d',
            'search_latest':'-1d@d',
            'trend_earliest':'-2y@d',
            'trend_latest':'-1y@d'
        },
        'all':{
            'status':'false',
            'search_earliest':'0',
            'search_latest':'-1d@d',
            'trend_earliest':'0',
            'trend_latest':'-1d@d'
        },


    };


    var defaultTokenModel = mvc.Components.get("default");
    var submittedTokenModel = mvc.Components.get("submitted");
    var initializeCountryIndex = {'index_Country':get_index_token()};

    defaultTokenModel.set(initializeCountryIndex);
    submittedTokenModel.set(initializeCountryIndex);

    defaultTokenModel.set({'search_earliest': time_values['30d'].search_earliest});
    submittedTokenModel.set({'search_earliest': time_values['30d'].search_earliest});

    defaultTokenModel.set({'search_latest': time_values['30d'].search_latest});
    submittedTokenModel.set({'search_latest': time_values['30d'].search_latest});


    defaultTokenModel.set({'trend_earliest': time_values['30d'].trend_earliest});
    submittedTokenModel.set({'trend_earliest': time_values['30d'].trend_earliest});

    defaultTokenModel.set({'trend_latest': time_values['30d'].trend_latest});
    submittedTokenModel.set({'trend_latest': time_values['30d'].trend_latest});




    ////add time buttons
    //// tokens are: $search_earliest$ $search_latest$
    let time_ranges = ['7d', '30d','pm', '3m', '1y', 'all'];



    let html="<ul class='custom-ul'>";
    for (let i=0;i<time_ranges.length;i++){
        html += "<li class='custom-li'><button "+ (time_ranges[i]=='30d'?'style="background:#011751;color:#fff;"':"style='background:#fff;color:#011751'") +" class='custom-button time-button' id='"+time_ranges[i]+"'>"+time_ranges[i]+"</button></li>";
    }
    html += "<li class='custom-li'><button style='background:#fff;color:#011751' class='custom-button functional-button' id='monthly_slider'>&lt;</button></li>";
    html+="</ul>";
    $('#time_buttons').html(html);

    $('#monthly_slider').on('click', function (event){
        let width = $('#monthly-slider-menu').width();
        console.log(width);
        if(width==0){
            $('#monthly-slider-menu').width("auto");
            $('#monthly_slider').html('&gt;');
        }
        else{
            $('#monthly-slider-menu').width(0);
            $('#monthly_slider').html('&lt;');
        }
    });

    /////MONTHLY TOKENS
    for(let i=1; i<=12; i++){
        time_values['-m'+i] = {
            'status':'false',
            'search_earliest':'-'+i+'month@month',
            'search_latest':'-'+(i-1)+'month@month',
            'trend_earliest':'-'+(i+1)+'month@month',
            'trend_latest':'-'+i+'month@month'
        }
    }
    let monthly_ranges = [];
    for(let i=1; i<=12; i++) {
        monthly_ranges.push('-m'+i);
    }

    html="<ul class='custom-ul'>";
    for (let i=0;i<monthly_ranges.length;i++){
        html += "<li class='custom-li'><button style='background:#fff;color:#011751;' class='custom-button time-button' id='"+monthly_ranges[i]+"'>"+monthly_ranges[i]+"</button></li>";
    }
    html+="</ul>";
    $('#monthly-slider-menu').html(html);

    ///click function for all monthly and time buttons
    $('.time-button').on('click',function(event){
        set_timetoken($(event.currentTarget).attr('id'));
    });



    ///add country buttons

    ////put somewhere on the dashboard a div/span/etc. with id="country_buttons"
    //// index token = $index_Country$
    //// <span id="country_buttons"></span>
    let img_path=window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':'+
        window.location.port: '') + "/en-US/static/app/myviz/";

    let indexes = ['div','de','es','fr','uk'];

    html="<ul class='custom-ul'>";
    for (let i=0;i<indexes.length;i++){
        html += "<li class='custom-li'><img class='button custom-button' id='"+indexes[i]+"_btn' src='"+img_path+indexes[i]+"_" + "color.png'/></li>";
    }
    html += "<li class='custom-li'><button class='custom-button functional-button' style='background:#fff;color:#011751;' id='X_btn'>X</button></li>";
    html+="</ul>";
    $('#country_buttons').html(html);

    ////token models


    function click_event_country_btn(event, btn, idx){
        let changeindex = {'index_Country':get_index_token(idx)};
        defaultTokenModel.set(changeindex);
        submittedTokenModel.set(changeindex);

        let img_str = img_path + idx +"_" + (index_values[idx].status=='true'?'color':'grey') +".png";
        $(btn).attr("src",img_str );
    }

    function clear_country_selection(){
        let changeindex = {'index_Country':get_index_token('x')};
        defaultTokenModel.set(changeindex);
        submittedTokenModel.set(changeindex);
        for(var idx in indexes){

            index_values[indexes[idx]].status = 'false';
            console.log(index_values[indexes[idx]].status);
            $('#'+indexes[idx]+'_btn').attr("src", img_path + indexes[idx] +"_grey.png");
        }
    }

    $('#X_btn').on('click', function(event){
        clear_country_selection();
    });

    $('#div_btn').on('click',function(event){
        click_event_country_btn(event, this, 'div');
    });
    $('#de_btn').on('click',function(event){
        click_event_country_btn(event,this, 'de');
    });
    $('#es_btn').on('click',function(event){
        click_event_country_btn(event,this, 'es');
    });
    $('#fr_btn').on('click',function(event){
        click_event_country_btn(event,this, 'fr');
    });
    $('#uk_btn').on('click',function(event){
        click_event_country_btn(event,this, 'uk');
    });


    function set_timetoken(time_range){

        for (var prop in time_values){


            if(time_values[prop].status=="true"){
                time_values[prop].status="false";
                $('#'+prop).attr("style","background:#fff;color:#011751");
            }
        }
        time_values[time_range].status="true";
        $('#'+time_range).attr("style","background:#011751;color:#fff");
        defaultTokenModel.set({'search_earliest': time_values[time_range].search_earliest});
        submittedTokenModel.set({'search_earliest': time_values[time_range].search_earliest});

        defaultTokenModel.set({'search_latest': time_values[time_range].search_latest});
        submittedTokenModel.set({'search_latest': time_values[time_range].search_latest});


        defaultTokenModel.set({'trend_earliest': time_values[time_range].trend_earliest});
        submittedTokenModel.set({'trend_earliest': time_values[time_range].trend_earliest});

        defaultTokenModel.set({'trend_latest': time_values[time_range].trend_latest});
        submittedTokenModel.set({'trend_latest': time_values[time_range].trend_latest});
    }


    function get_index_token(index_to_toggle){

        let str_ = '',
            first=true;

        if(index_to_toggle=="x"){
            return str_;
        }

        if(index_to_toggle != null){
            index_values[index_to_toggle].status = toggle(index_values[index_to_toggle].status);
        }

        for (var property in index_values) {
            if(index_values[property].status=="true"){
                if (first){
                    str_ = index_prefix + property;
                    first=false;
                }
                else{
                    str_ = str_ + index_delimeter + index_prefix + property;
                }
            }
        }

        for ( let i=0;i<index_values.length;i++){
            if(index_values[i].status=="true"){

                if (first){
                    str_ = index_prefix + index_values[i].value;
                    first=false;
                }
                else{
                    str_ = str_ + index_delimeter + index_prefix + index_values[i].value;
                }
            }
        }

        return str_

    }

    function toggle(x){
        if (x=="true"){
            return 'false';
        }
        else{
            return 'true';
        }
    }




    //DEBUGGING
    //console.log(info_triggers);
    //console.log(defaultTokenModel);
    //console.log(submittedTokenModel);
    //console.log(time_values);
    //console.log(initializeCountryIndex);
    //console.log(html);
    //console.log("14:08");


});